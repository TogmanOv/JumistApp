const admin = require("firebase-admin/app");
admin.initializeApp();

const fetchPositionInfo = require("./fetch_position_info.js");
exports.fetchPositionInfo = fetchPositionInfo.fetchPositionInfo;
