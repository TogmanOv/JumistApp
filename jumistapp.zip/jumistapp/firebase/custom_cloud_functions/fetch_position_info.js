const functions = require("firebase-functions");
const admin = require("firebase-admin");
const fetch = require("node-fetch");
const cheerio = require("cheerio");

exports.fetchPositionInfo = functions.https.onRequest(
  async (request, response) => {
    try {
      const url = request.query.url; // Assuming you pass the URL as a query parameter

      if (!url) {
        response.status(400).send("URL parameter is missing");
        return;
      }

      const res = await fetch(url);
      const html = await res.text();

      const $ = cheerio.load(html);
      const bodyContent = $("body").html();

      response.status(200).send({
        content: bodyContent,
      });
    } catch (error) {
      response.status(500).send(`Error fetching content: ${error.message}`);
    }
  },
);
