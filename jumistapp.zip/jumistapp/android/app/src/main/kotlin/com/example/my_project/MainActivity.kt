package com.aitu.jumistapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
