import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'es', 'zh_Hans', 'hi', 'tl'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? esText = '',
    String? zh_HansText = '',
    String? hiText = '',
    String? tlText = '',
  }) =>
      [enText, esText, zh_HansText, hiText, tlText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    final language = locale.toString();
    return FFLocalizations.languages().contains(
      language.endsWith('_')
          ? language.substring(0, language.length - 1)
          : language,
    );
  }

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // HomePage
  {
    'gywpnv60': {
      'en': 'Find Jobs',
      'es': 'Encontrar trabajos',
      'hi': 'नौकरी ढूंढे',
      'tl': 'Maghanap ng mga Trabaho',
      'zh_Hans': '寻找工作',
    },
    'gwftlnol': {
      'en':
          'Escape the clutter of job boards with our unique job search tool, which aligns your skills with roles directly on employer career pages for a more personalized application process.',
      'es':
          'Escápese del desorden de las bolsas de trabajo con nuestra exclusiva herramienta de búsqueda de empleo, que alinea sus habilidades con los roles directamente en las páginas de carrera del empleador para un proceso de solicitud más personalizado.',
      'hi':
          'हमारे अनूठे जॉब सर्च टूल के साथ जॉब बोर्डों की अव्यवस्था से बचें, जो अधिक वैयक्तिकृत आवेदन प्रक्रिया के लिए आपके कौशल को सीधे नियोक्ता कैरियर पृष्ठों पर भूमिकाओं के साथ संरेखित करता है।',
      'tl':
          'Takasan ang kalat ng mga job board gamit ang aming natatanging tool sa paghahanap ng trabaho, na iniayon ang iyong mga kasanayan sa mga tungkulin nang direkta sa mga pahina ng karera ng employer para sa isang mas personalized na proseso ng aplikasyon.',
      'zh_Hans':
          '使用我们独特的求职工具摆脱求职板的混乱，该工具直接在雇主职业页面上将您的技能与职位进行匹配，从而实现更加个性化的申请流程。',
    },
    't37xsz4t': {
      'en': 'Tell us what you can do, or what you want to do?',
      'es': '¿Cuéntanos qué puedes hacer o qué quieres hacer?',
      'hi': 'हमें बताएं कि आप क्या कर सकते हैं, या आप क्या करना चाहते हैं?',
      'tl':
          'Sabihin sa amin kung ano ang maaari mong gawin, o kung ano ang gusto mong gawin?',
      'zh_Hans': '告诉我们你能做什么，或者你想做什么？',
    },
    'hpvf176i': {
      'en': 'Skills',
      'es': 'Habilidades',
      'hi': 'कौशल',
      'tl': 'Mga kasanayan',
      'zh_Hans': '技能',
    },
    'zzjr0at7': {
      'en': 'customer service, HTML, management, etc...',
      'es': 'atención al cliente, HTML, gestión, etc...',
      'hi': 'ग्राहक सेवा, HTML, प्रबंधन, आदि...',
      'tl': 'serbisyo sa customer, HTML, pamamahala, atbp...',
      'zh_Hans': '客户服务、HTML、管理等...',
    },
    'w7ndz0i9': {
      'en': 'Location',
      'es': 'Ubicación',
      'hi': 'जगह',
      'tl': 'Lokasyon',
      'zh_Hans': '地点',
    },
    'h636hede': {
      'en': 'Los Angeles, CA, Remote, etc...',
      'es': 'Los Ángeles, CA, Remoto, etc...',
      'hi': 'लॉस एंजिल्स, सीए, रिमोट, आदि...',
      'tl': 'Los Angeles, CA, Remote, atbp...',
      'zh_Hans': '洛杉矶、加利福尼亚州、偏远地区等...',
    },
    '7sca4kne': {
      'en': 'Find',
      'es': 'Encontrar',
      'hi': 'खोजो',
      'tl': 'Hanapin',
      'zh_Hans': '寻找',
    },
    '44cp1vlr': {
      'en': 'Coach',
      'es': 'Entrenador',
      'hi': 'प्रशिक्षक',
      'tl': 'coach',
      'zh_Hans': '教练',
    },
    '4mflm3qt': {
      'en': 'Enhance',
      'es': 'Mejorar',
      'hi': 'बढ़ाना',
      'tl': 'Pagandahin',
      'zh_Hans': '提高',
    },
    'w4j55qd7': {
      'en': 'Write',
      'es': 'Escribir',
      'hi': 'लिखना',
      'tl': 'Sumulat',
      'zh_Hans': '写',
    },
    'h7rxi3dq': {
      'en': 'Profile',
      'es': 'Perfil',
      'hi': 'प्रोफ़ाइल',
      'tl': 'Profile',
      'zh_Hans': '轮廓',
    },
    'lme5sqc0': {
      'en': 'Find',
      'es': 'Encontrar',
      'hi': 'खोजो',
      'tl': 'Hanapin',
      'zh_Hans': '寻找',
    },
  },
  // LogInPage
  {
    'n0oj3ebn': {
      'en': 'Jumistapp',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'h4wasm0z': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'lw3ffq5m': {
      'en': 'Welcome Back',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '3x7ek123': {
      'en': 'Let\'s get started by filling out the form below',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'wojf2m09': {
      'en': 'Email',
      'es': 'Correo electrónico',
      'hi': 'ईमेल',
      'tl': 'Email',
      'zh_Hans': '电子邮件',
    },
    'hpqm5qdw': {
      'en': 'Password',
      'es': 'Contraseña',
      'hi': 'पासवर्ड',
      'tl': 'Password',
      'zh_Hans': '密码',
    },
    'xzfit3ph': {
      'en': 'Forgot Password?',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'm03zuyz2': {
      'en': 'Sign in',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'rtosgiut': {
      'en': 'Don\'t have an account? Sign Up',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '4zmvusut': {
      'en': 'Privacy Policy',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // SignUpPage2ResumeUpload
  {
    '1tplreta': {
      'en': 'Jumistapp',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ceqoc9mz': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'lhsiqtgb': {
      'en': 'Create Profile',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'u29ewx9v': {
      'en':
          'Upload your resume and we will create the profile for you, or enter your details manually',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '7qr6n5q7': {
      'en': 'Upload your resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '1s65ar8u': {
      'en': 'Enter Details Manually',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'wcfp0jxk': {
      'en': 'Privacy Policy',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // ResetPassword
  {
    'ajys4ghi': {
      'en': 'Jumistapp',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'b8wsic49': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'vmljiip6': {
      'en': 'Reset password',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'v7bnh6ma': {
      'en':
          'Enter your email and we will send you instruction for reseting the password',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'uualv637': {
      'en': 'Email',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'g94f1f3o': {
      'en': 'Reset Password',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'uqtl0v7f': {
      'en': 'Don\'t have an account? Sign up',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '9qbqsgbt': {
      'en': 'Remember your password? Sign in',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'rqomfn92': {
      'en': 'Privacy Policy',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // CareerCoachResults
  {
    'q7xvp1bg': {
      'en': 'CareerCoach Report',
      'es': 'Informe de CareerCoach',
      'hi': 'करियरकोच रिपोर्ट',
      'tl': 'Ulat ng CareerCoach',
      'zh_Hans': '职业教练报告',
    },
    '60ahsccm': {
      'en': 'If you see \"null\" paste less text of the job description.',
      'es': 'Si ve \"nulo\", pegue menos texto de la descripción del trabajo.',
      'hi':
          'यदि आपको \"शून्य\" दिखाई देता है तो कार्य विवरण का कम पाठ चिपकाएँ।',
      'tl':
          'Kung nakikita mo ang \"null\" i-paste ang mas kaunting teksto ng paglalarawan ng trabaho.',
      'zh_Hans': '如果您看到“null”，请粘贴较少的职位描述文本。',
    },
    'kzev4r19': {
      'en': 'Resume Optimization Tips',
      'es': 'Consejos para optimizar el currículum',
      'hi': 'अनुकूलन युक्तियाँ फिर से शुरू करें',
      'tl': 'Ipagpatuloy ang Mga Tip sa Pag-optimize',
      'zh_Hans': '简历优化技巧',
    },
    '8781l9i6': {
      'en': 'Other Jobs That Match Your Skills',
      'es': 'Otros trabajos que coinciden con sus habilidades',
      'hi': 'अन्य नौकरियाँ जो आपके कौशल से मेल खाती हैं',
      'tl': 'Iba Pang Trabaho na Katugma sa Iyong Mga Kakayahan',
      'zh_Hans': '其他适合您技能的工作',
    },
    'm14hpb9i': {
      'en': 'Cover Letter',
      'es': 'Carta de presentación',
      'hi': 'कवर लेटर',
      'tl': 'Cover Letter',
      'zh_Hans': '求职信',
    },
    '8sngb3c9': {
      'en':
          'Be sure to proofread for accuracy and to add any additional details!',
      'es':
          '¡Asegúrese de revisar para mayor precisión y agregar detalles adicionales!',
      'hi':
          'सटीकता के लिए प्रूफ़रीड करना और कोई अतिरिक्त विवरण जोड़ना सुनिश्चित करें!',
      'tl':
          'Siguraduhing mag-proofread para sa katumpakan at magdagdag ng anumang karagdagang mga detalye!',
      'zh_Hans': '请务必校对准确性并添加任何其他详细信息！',
    },
    'dnfx77h5': {
      'en': 'Outreach Messages',
      'es': 'Mensajes de divulgación',
      'hi': 'आउटरीच संदेश',
      'tl': 'Outreach Messages',
      'zh_Hans': '外展信息',
    },
    'bjac0aem': {
      'en': 'Interview Plan',
      'es': 'Plan de entrevista',
      'hi': 'साक्षात्कार योजना',
      'tl': 'Plano ng Panayam',
      'zh_Hans': '面试计划',
    },
    'wva1lu2b': {
      'en': 'Questions You Can Ask the Company',
      'es': 'Preguntas que puede hacerle a la empresa',
      'hi': 'प्रश्न जो आप कंपनी से पूछ सकते हैं',
      'tl': 'Mga Tanong na Maari Mong Itanong sa Kumpanya',
      'zh_Hans': '您可以向公司询问的问题',
    },
    'g2krfkwf': {
      'en': 'Candidate Assessment',
      'es': 'Evaluación del candidato',
      'hi': 'उम्मीदवार का आकलन',
      'tl': 'Pagsusuri ng Kandidato',
      'zh_Hans': '候选人评估',
    },
    'bjw35s47': {
      'en': 'Job Summary',
      'es': 'Resumen de trabajo',
      'hi': 'नौकरी का सारांश',
      'tl': 'Buod ng Trabaho',
      'zh_Hans': '工作总结',
    },
    'cnbu8j3s': {
      'en': 'Compensation Analysis',
      'es': 'Análisis de compensación',
      'hi': 'मुआवज़ा विश्लेषण',
      'tl': 'Pagsusuri ng Kompensasyon',
      'zh_Hans': '薪酬分析',
    },
    'riv7qs6d': {
      'en': 'Role Expectations',
      'es': 'Expectativas de rol',
      'hi': 'भूमिका अपेक्षाएँ',
      'tl': 'Mga Inaasahan sa Tungkulin',
      'zh_Hans': '角色期望',
    },
    'npqwqxwn': {
      'en': 'Find  Jobs',
      'es': 'Encontrar trabajos',
      'hi': 'नौकरी ढूंढे',
      'tl': 'Maghanap ng mga Trabaho',
      'zh_Hans': '寻找工作',
    },
    'sgv7kery': {
      'en':
          'Based on your resume, Career Coach can show you other jobs that match your skillset. Simply enter where you wish to find jobs!',
      'es':
          'Según su currículum, Career Coach puede mostrarle otros trabajos que coincidan con sus habilidades. ¡Simplemente ingrese dónde desea encontrar trabajo!',
      'hi':
          'आपके बायोडाटा के आधार पर, करियर कोच आपको अन्य नौकरियां दिखा सकता है जो आपके कौशल से मेल खाती हैं। बस वहां दर्ज करें जहां आप नौकरी ढूंढना चाहते हैं!',
      'tl':
          'Batay sa iyong resume, maaaring ipakita sa iyo ng Career Coach ang iba pang mga trabaho na tumutugma sa iyong skillset. Ipasok lamang kung saan mo gustong maghanap ng trabaho!',
      'zh_Hans': '根据您的简历，职业教练可以向您展示与您的技能相匹配的其他工作。只需输入您想找工作的地方即可！',
    },
    'dsdsz09v': {
      'en': 'Enter the location you want to find jobs:',
      'es': 'Ingrese la ubicación donde desea encontrar trabajos:',
      'hi': 'वह स्थान दर्ज करें जहाँ आप नौकरियाँ ढूँढना चाहते हैं:',
      'tl': 'Ilagay ang lokasyon na gusto mong maghanap ng mga trabaho:',
      'zh_Hans': '输入您要寻找工作的地点：',
    },
    '191hc7oc': {
      'en': 'Los Angeles, CA, Remote, etc...',
      'es': 'Los Ángeles, CA, Remoto, etc...',
      'hi': 'लॉस एंजिल्स, सीए, रिमोट, आदि...',
      'tl': 'Los Angeles, CA, Remote, atbp...',
      'zh_Hans': '洛杉矶、加利福尼亚州、偏远地区等...',
    },
    'qjmlxgen': {
      'en': 'Find me jobs',
      'es': 'Búscame trabajos',
      'hi': 'मेरे लिए नौकरियाँ ढूँढ़ो',
      'tl': 'Maghanap ako ng trabaho',
      'zh_Hans': '给我找工作',
    },
    'b2jd37k9': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    'sr40z1lp': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'g9wjd1ak': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    '6b1etmp4': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'wq8eu1t2': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    '7wz4um9w': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'b9tcu7m1': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    '8ko7rgag': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'f0v5lqsq': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    '3xl4c6bk': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'nucjti5c': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    '925783rb': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    '3ryleosw': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    'e4ao3bur': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'whjp60oz': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    'bc816oju': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    '8fgk7ohq': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    'x67yck0e': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'kvls681v': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    'bp9q8u76': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'v482d78g': {
      'en': 'Wait for results',
      'es': 'Esperar resultados',
      'hi': 'परिणामों की प्रतीक्षा करें',
      'tl': 'Maghintay para sa mga resulta',
      'zh_Hans': '等待结果',
    },
    'v2w1jsn4': {
      'en': 'Please choose an option from the dropdown',
      'es': 'Por favor elija una opción del menú desplegable',
      'hi': 'कृपया ड्रॉपडाउन से एक विकल्प चुनें',
      'tl': 'Mangyaring pumili ng opsyon mula sa dropdown',
      'zh_Hans': '请从下拉列表中选择一个选项',
    },
    'dmd5t2yl': {
      'en': 'Career Coach',
      'es': 'Entrenador de carrera',
      'hi': 'कैरियर कोच',
      'tl': 'Career Coach',
      'zh_Hans': '职业教练',
    },
  },
  // ProfilePage
  {
    'ojwsn8zk': {
      'en': 'Profile',
      'es': 'Perfil',
      'hi': 'प्रोफ़ाइल',
      'tl': 'Profile',
      'zh_Hans': '轮廓',
    },
    'e7k5xxr7': {
      'en': 'Show my saved resume',
      'es': 'Mostrar mi currículum guardado',
      'hi': 'मेरा सहेजा गया बायोडाटा दिखाओ',
      'tl': 'Ipakita ang aking naka-save na resume',
      'zh_Hans': '显示我保存的简历',
    },
    'be5h1lgn': {
      'en': 'CareerCoach Reports',
      'es': 'Informes de CareerCoach',
      'hi': 'कैरियरकोच रिपोर्ट',
      'tl': 'Mga Ulat ng CareerCoach',
      'zh_Hans': '职业教练报告',
    },
    '8skn9z65': {
      'en': 'Written Resumes',
      'es': 'CV escritos',
      'hi': 'लिखित बायोडाटा',
      'tl': 'Mga Nakasulat na Resume',
      'zh_Hans': '书面简历',
    },
    'bmrlis38': {
      'en': 'Privacy Policy',
      'es': 'política de privacidad',
      'hi': 'गोपनीयता नीति',
      'tl': 'Patakaran sa Privacy',
      'zh_Hans': '隐私政策',
    },
    'i59a3ocm': {
      'en': 'Terms of Use',
      'es': 'Condiciones de uso',
      'hi': 'उपयोग की शर्तें',
      'tl': 'Mga Tuntunin ng Paggamit',
      'zh_Hans': '使用条款',
    },
    'ljgakub2': {
      'en': 'Profile',
      'es': 'Perfil',
      'hi': 'प्रोफ़ाइल',
      'tl': 'Profile',
      'zh_Hans': '轮廓',
    },
  },
  // CareerCoachDetailsPage
  {
    'f1wyn036': {
      'en': 'Resume Optimization Tips',
      'es': 'Consejos para optimizar el currículum',
      'hi': 'अनुकूलन युक्तियाँ फिर से शुरू करें',
      'tl': 'Ipagpatuloy ang Mga Tip sa Pag-optimize',
      'zh_Hans': '简历优化技巧',
    },
    '9dbkhwti': {
      'en': 'Other Jobs That Match Your Skills',
      'es': 'Otros trabajos que coinciden con sus habilidades',
      'hi': 'अन्य नौकरियाँ जो आपके कौशल से मेल खाती हैं',
      'tl': 'Iba Pang Trabaho na Katugma sa Iyong Mga Kakayahan',
      'zh_Hans': '其他适合您技能的工作',
    },
    'um1zq9q5': {
      'en': 'Cover Letter',
      'es': 'Carta de presentación',
      'hi': 'कवर लेटर',
      'tl': 'Cover Letter',
      'zh_Hans': '求职信',
    },
    '05niohec': {
      'en':
          'Be sure to proofread for accuracy and to add any additional details!',
      'es':
          '¡Asegúrese de revisar para mayor precisión y agregar detalles adicionales!',
      'hi':
          'सटीकता के लिए प्रूफ़रीड करना और कोई अतिरिक्त विवरण जोड़ना सुनिश्चित करें!',
      'tl':
          'Siguraduhing mag-proofread para sa katumpakan at magdagdag ng anumang karagdagang mga detalye!',
      'zh_Hans': '请务必校对准确性并添加任何其他详细信息！',
    },
    'x6veaz3m': {
      'en': 'Outreach Messages',
      'es': 'Mensajes de divulgación',
      'hi': 'आउटरीच संदेश',
      'tl': 'Outreach Messages',
      'zh_Hans': '外展信息',
    },
    'b8n85pe0': {
      'en': 'Interview Plan',
      'es': 'Plan de entrevista',
      'hi': 'साक्षात्कार योजना',
      'tl': 'Plano ng Panayam',
      'zh_Hans': '面试计划',
    },
    'illatvob': {
      'en': 'Questions You Can Ask the Company',
      'es': 'Preguntas que puede hacerle a la empresa',
      'hi': 'प्रश्न जो आप कंपनी से पूछ सकते हैं',
      'tl': 'Mga Tanong na Maari Mong Itanong sa Kumpanya',
      'zh_Hans': '您可以向公司询问的问题',
    },
    'njb8w5g8': {
      'en': 'Candidate Assessment',
      'es': 'Evaluación del candidato',
      'hi': 'उम्मीदवार का आकलन',
      'tl': 'Pagsusuri ng Kandidato',
      'zh_Hans': '候选人评估',
    },
    '1wl4sjpk': {
      'en': 'Job Summary',
      'es': 'Resumen de trabajo',
      'hi': 'नौकरी का सारांश',
      'tl': 'Buod ng Trabaho',
      'zh_Hans': '工作总结',
    },
    'o17zmw7n': {
      'en': 'Compensation Analysis',
      'es': 'Análisis de compensación',
      'hi': 'मुआवज़ा विश्लेषण',
      'tl': 'Pagsusuri ng Kompensasyon',
      'zh_Hans': '薪酬分析',
    },
    'n7xy9k5n': {
      'en': 'Role Expectations',
      'es': 'Expectativas de rol',
      'hi': 'भूमिका अपेक्षाएँ',
      'tl': 'Mga Inaasahan sa Tungkulin',
      'zh_Hans': '角色期望',
    },
    'vqtorzrp': {
      'en': 'Career Coach',
      'es': 'Entrenador de carrera',
      'hi': 'कैरियर कोच',
      'tl': 'Career Coach',
      'zh_Hans': '职业教练',
    },
  },
  // ResumeEnhancerUpload
  {
    '5sexqcy2': {
      'en': 'Resume Enhancer\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'z6akfzru': {
      'en': 'Enhance your resume in under a minute',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ch8gwxje': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'jw37jy2h': {
      'en': 'Upload a new resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '1h274lax': {
      'en': 'Remove this file',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'd03un77j': {
      'en': 'Or',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'bwhein1x': {
      'en': 'Select From Previously Saved Resumes  ',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ndkibk6y': {
      'en': 'Option 1',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'npn79c12': {
      'en': 'Enhance',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'zd4zme5l': {
      'en': 'Enhance',
      'es': 'Mejorar',
      'hi': 'बढ़ाना',
      'tl': 'Pagandahin',
      'zh_Hans': '提高',
    },
  },
  // ResumeEnhanceResultPage
  {
    'zztd7tzv': {
      'en': 'Tips to Enhance Your Resume',
      'es': 'Consejos para mejorar su currículum',
      'hi': 'आपके बायोडाटा को बेहतर बनाने के लिए युक्तियाँ',
      'tl': 'Mga Tip para Pagandahin ang Iyong Resume',
      'zh_Hans': '增强简历的技巧',
    },
    'v3verpye': {
      'en':
          'Below are tips, potential metrics to add to your resume, and a sample career trajectory and career pivot options:',
      'es':
          'A continuación se incluyen consejos, posibles métricas para agregar a su currículum y un ejemplo de trayectoria profesional y opciones de pivote profesional:',
      'hi':
          'नीचे युक्तियाँ, आपके बायोडाटा में जोड़ने के लिए संभावित मेट्रिक्स और एक नमूना कैरियर प्रक्षेपवक्र और कैरियर धुरी विकल्प दिए गए हैं:',
      'tl':
          'Nasa ibaba ang mga tip, potensyal na sukatan na idaragdag sa iyong resume, at isang sample na career trajectory at career pivot na mga opsyon:',
      'zh_Hans': '以下是提示、可添加到简历中的潜在指标以及职业轨迹和职业枢纽选项示例：',
    },
    '3qxfcrs2': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // resumeWriter
  {
    'wbewapeg': {
      'en': 'CareerCoach',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'on0iosq9': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ssvjufrs': {
      'en': 'Resume name',
      'es': 'Etiqueta aquí...',
      'hi': 'यहां लेबल करें...',
      'tl': 'Label dito...',
      'zh_Hans': '在这里标记...',
    },
    'ew06s688': {
      'en': 'Submit',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '9su07is1': {
      'en': 'Find',
      'es': 'Encontrar',
      'hi': 'खोजो',
      'tl': 'Hanapin',
      'zh_Hans': '寻找',
    },
    'v9qlz09m': {
      'en': 'Coach',
      'es': 'Entrenador',
      'hi': 'प्रशिक्षक',
      'tl': 'coach',
      'zh_Hans': '教练',
    },
    '2xx9cctq': {
      'en': 'Enhance',
      'es': 'Mejorar',
      'hi': 'बढ़ाना',
      'tl': 'Pagandahin',
      'zh_Hans': '提高',
    },
    'e7byxcql': {
      'en': 'Write',
      'es': 'Escribir',
      'hi': 'लिखना',
      'tl': 'Sumulat',
      'zh_Hans': '写',
    },
    'q58ml225': {
      'en': 'Profile',
      'es': 'Perfil',
      'hi': 'प्रोफ़ाइल',
      'tl': 'Profile',
      'zh_Hans': '轮廓',
    },
    'fwgvqq76': {
      'en': 'Write',
      'es': 'Escribir',
      'hi': 'लिखना',
      'tl': 'Sumulat',
      'zh_Hans': '写',
    },
  },
  // WrittenResume
  {
    'kju8qfyn': {
      'en': 'title',
      'es': 'título',
      'hi': 'शीर्षक',
      'tl': 'pamagat',
      'zh_Hans': '标题',
    },
    'i3aa76n6': {
      'en':
          'Be sure to proofread and edit for accuracy!\nFor example, there may be placeholders for certifications and education',
      'es':
          '¡Asegúrese de revisar y editar para mayor precisión!\nPor ejemplo, puede haber marcadores de posición para certificaciones y educación.',
      'hi':
          'सटीकता के लिए प्रूफ़रीड और संपादन करना सुनिश्चित करें!\nउदाहरण के लिए, प्रमाणपत्र और शिक्षा के लिए प्लेसहोल्डर हो सकते हैं',
      'tl':
          'Tiyaking i-proofread at i-edit para sa katumpakan!\nHalimbawa, maaaring may mga placeholder para sa mga sertipikasyon at edukasyon',
      'zh_Hans': '请务必校对和编辑以确保准确性！\n例如，可能有认证和教育的占位符',
    },
    'u407eaca': {
      'en': 'resume',
      'es': 'reanudar',
      'hi': 'फिर शुरू करना',
      'tl': 'ipagpatuloy',
      'zh_Hans': '恢复',
    },
    '4kbj27x6': {
      'en': 'Your Written Resume',
      'es': 'Su currículum escrito',
      'hi': 'आपका लिखित बायोडाटा',
      'tl': 'Iyong Nakasulat na Resume',
      'zh_Hans': '您的书面简历',
    },
    'v69c4uki': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // LearnMorePage
  {
    '7c2n9y3w': {
      'en': 'See how CareerCoach works here:',
      'es': 'Vea cómo funciona CareerCoach aquí:',
      'hi': 'यहां देखें कि करियरकोच कैसे काम करता है:',
      'tl': 'Tingnan kung paano gumagana ang CareerCoach dito:',
      'zh_Hans': '在这里查看 CareerCoach 的工作原理：',
    },
    '6r99v714': {
      'en':
          'CareerCoach helps you stand out for the job you’ve always wanted. \nHere is what you can expect:',
      'es':
          'CareerCoach te ayuda a destacar por el trabajo que siempre has deseado.\nEsto es lo que puede esperar:',
      'hi':
          'करियरकोच आपको उस नौकरी के लिए खड़ा होने में मदद करता है जो आप हमेशा से चाहते थे।\nयहाँ आप क्या उम्मीद कर सकते हैं:',
      'tl':
          'Tinutulungan ka ng CareerCoach na tumayo para sa trabahong gusto mo noon pa man.\nNarito ang maaari mong asahan:',
      'zh_Hans': 'CareerCoach 帮助您在您一直想要的工作中脱颖而出。\n以下是您可以期待的：',
    },
    'scdaem95': {
      'en': 'Specific feedback on your resume',
      'es': 'Comentarios específicos sobre su currículum',
      'hi': 'आपके बायोडाटा पर विशिष्ट प्रतिक्रिया',
      'tl': 'Tukoy na feedback sa iyong resume',
      'zh_Hans': '对简历的具体反馈',
    },
    '1yghbjh3': {
      'en':
          '- General tips to improve it\n- Tips to make it better match the job you want\n- Recommendations of metrics to add',
      'es':
          '- Consejos generales para mejorarlo.\n- Consejos para que coincida mejor con el trabajo que deseas\n- Recomendaciones de métricas para agregar',
      'hi':
          '- इसे सुधारने के लिए सामान्य युक्तियाँ\n- अपनी इच्छित नौकरी से इसे बेहतर ढंग से मेल कराने के लिए युक्तियाँ\n- जोड़ने के लिए मेट्रिक्स की सिफ़ारिशें',
      'tl':
          '- Pangkalahatang mga tip upang mapabuti ito\n- Mga tip upang gawin itong mas mahusay na tumugma sa trabaho na gusto mo\n- Mga rekomendasyon ng mga sukatan na idaragdag',
      'zh_Hans': '- 改进的一般技巧\n- 使其更好地匹配您想要的工作的提示\n- 添加指标的建议',
    },
    'pzvg0u3c': {
      'en': 'A customized cover letter',
      'es': 'Una carta de presentación personalizada',
      'hi': 'एक अनुकूलित कवर पत्र',
      'tl': 'Isang customized na cover letter',
      'zh_Hans': '定制的求职信',
    },
    'm1iqoayg': {
      'en':
          '- A cover letter for the job you want\n- Written based on your actual resume and experience\n- Aligns your experience to what the company is seeking in a candidate',
      'es':
          '- Una carta de presentación para el trabajo que deseas.\n- Escrito en base a su currículum y experiencia reales.\n- Alinea tu experiencia con lo que la empresa busca en un candidato',
      'hi':
          '- आप जो नौकरी चाहते हैं उसके लिए एक कवर लेटर\n- आपके वास्तविक बायोडाटा और अनुभव के आधार पर लिखा गया\n- आपके अनुभव को कंपनी एक उम्मीदवार से क्या चाह रही है, उसके अनुरूप बनाता है',
      'tl':
          '- Isang cover letter para sa trabahong gusto mo\n- Isinulat batay sa iyong aktwal na resume at karanasan\n- Inihanay ang iyong karanasan sa kung ano ang hinahanap ng kumpanya sa isang kandidato',
      'zh_Hans': '- 您想要的工作的求职信\n- 根据您的实际简历和经验撰写\n- 使您的经验与公司对候选人的要求相一致',
    },
    'hmfuz8e0': {
      'en': 'Outreach messages',
      'es': 'Mensajes de divulgación',
      'hi': 'आउटरीच संदेश',
      'tl': 'Mga mensahe ng outreach',
      'zh_Hans': '外展消息',
    },
    '1fbgd83j': {
      'en':
          '- Be proactive and send customized outreach messages to hiring managers\n- Written with your experience as source content\n- Stand out by making a great first impression',
      'es':
          '- Sea proactivo y envíe mensajes de divulgación personalizados a los gerentes de contratación.\n- Escrito con tu experiencia como contenido fuente.\n- Destaca dando una excelente primera impresión',
      'hi':
          '- सक्रिय रहें और नियुक्ति करने वाले प्रबंधकों को अनुकूलित आउटरीच संदेश भेजें\n- स्रोत सामग्री के रूप में आपके अनुभव के साथ लिखा गया\n- पहली बार में ही बेहतरीन प्रभाव डालकर अलग दिखें',
      'tl':
          '- Maging maagap at magpadala ng mga naka-customize na mensahe ng outreach sa pagkuha ng mga manager\n- Isinulat gamit ang iyong karanasan bilang pinagmulang nilalaman\n- Manindigan sa pamamagitan ng paggawa ng magandang unang impression',
      'zh_Hans': '- 积极主动，向招聘经理发送定制的外展信息\n- 以您的经验作为源内容编写\n- 留下良好的第一印象，脱颖而出',
    },
    '5s88y4we': {
      'en': 'Interview plan',
      'es': 'Plan de entrevista',
      'hi': 'साक्षात्कार योजना',
      'tl': 'Plano ng panayam',
      'zh_Hans': '面试计划',
    },
    'l2g42eqd': {
      'en':
          '- Sample interview questions for the job with sample answers based on your actual experience\n- Questions for you to ask the company',
      'es':
          '- Ejemplos de preguntas de entrevista para el trabajo con respuestas de muestra basadas en su experiencia real\n- Preguntas para que le hagas a la empresa',
      'hi':
          '- आपके वास्तविक अनुभव के आधार पर नमूना उत्तरों के साथ नौकरी के लिए नमूना साक्षात्कार प्रश्न\n- आपके लिए कंपनी से पूछने के लिए प्रश्न',
      'tl':
          '- Mga halimbawang tanong sa panayam para sa trabaho na may mga sample na sagot batay sa iyong aktwal na karanasan\n- Mga tanong na itatanong mo sa kumpanya',
      'zh_Hans': '- 该职位的面试问题示例以及基于您实际经验的示例答案\n- 您可以向公司询问的问题',
    },
    '495m0gc0': {
      'en': 'Pre-employment assessment',
      'es': 'Evaluación previa al empleo',
      'hi': 'रोजगार पूर्व मूल्यांकन',
      'tl': 'Pagtatasa bago ang pagtatrabaho',
      'zh_Hans': '聘前评估',
    },
    '8z4ntomz': {
      'en':
          '- A sample pre-employment assessment to test your practical knowledge of the role',
      'es':
          '- Un ejemplo de evaluación previa al empleo para poner a prueba su conocimiento práctico del puesto.',
      'hi':
          '- भूमिका के बारे में आपके व्यावहारिक ज्ञान का परीक्षण करने के लिए रोजगार पूर्व मूल्यांकन का एक नमूना',
      'tl':
          '- Isang sample na pagtatasa bago ang pagtatrabaho upang subukan ang iyong praktikal na kaalaman sa tungkulin',
      'zh_Hans': '- 就业前评估样本，以测试您对该职位的实际知识',
    },
    'cr9xm8js': {
      'en': 'Job summary',
      'es': 'Resumen de trabajo',
      'hi': 'नौकरी का सारांश',
      'tl': 'Buod ng trabaho',
      'zh_Hans': '工作总结',
    },
    '7ah8v4kr': {
      'en':
          '- A summary of the job\n- A 30, 60, 90 day expectation summary so you know what to expect once you have the job\n- Compensation analysis so you know the average pay for the job',
      'es':
          '- Un resumen del trabajo.\n- Un resumen de expectativas de 30, 60 y 90 días para que sepas qué esperar una vez que tengas el trabajo.\n- Análisis de remuneración para que conozcas el salario medio del trabajo.',
      'hi':
          '- कार्य का सारांश\n- 30, 60, 90 दिनों की अपेक्षाओं का सारांश ताकि आप जान सकें कि नौकरी मिलने के बाद आपको क्या उम्मीद करनी है\n- मुआवज़ा विश्लेषण ताकि आप नौकरी के लिए औसत वेतन जान सकें',
      'tl':
          '- Isang buod ng trabaho\n- Isang 30, 60, 90 araw na buod ng inaasahan upang malaman mo kung ano ang aasahan kapag mayroon ka ng trabaho\n- Pagsusuri ng kompensasyon para malaman mo ang average na suweldo para sa trabaho',
      'zh_Hans':
          '- 工作总结\n- 30、60、90 天的期望总结，以便您知道获得工作后会发生什么\n- 薪酬分析，让您了解该工作的平均薪酬',
    },
    'gk5qy8ng': {
      'en': 'Job sourcing',
      'es': 'Búsqueda de empleo',
      'hi': 'जॉब सोर्सिंग',
      'tl': 'Pagkuha ng trabaho',
      'zh_Hans': '工作寻找',
    },
    'h6ehztln': {
      'en':
          '- By simply entering in the city you wish to work, we will provide you a list of jobs available\n- The jobs will be specifically chosen to match your skillset',
      'es':
          '- Con solo ingresar la ciudad en la que deseas trabajar, te proporcionaremos una lista de trabajos disponibles\n- Los trabajos se elegirán específicamente para que coincidan con sus habilidades.',
      'hi':
          '- आप जिस शहर में काम करना चाहते हैं, उसमें प्रवेश करते ही हम आपको उपलब्ध नौकरियों की एक सूची प्रदान करेंगे\n- नौकरियाँ विशेष रूप से आपके कौशल से मेल खाने के लिए चुनी जाएंगी',
      'tl':
          '- Sa simpleng pagpasok sa lungsod na gusto mong magtrabaho, bibigyan ka namin ng listahan ng mga trabahong available\n- Ang mga trabaho ay partikular na pipiliin upang tumugma sa iyong skillset',
      'zh_Hans': '- 只需输入您想要工作的城市，我们就会为您提供可用的工作列表\n- 这些工作将根据您的技能进行专门选择',
    },
    '2nshcw1l': {
      'en': 'Try it now!',
      'es': '¡Pruebalo ahora!',
      'hi': 'अब इसे आजमाओ!',
      'tl': 'Subukan ito ngayon!',
      'zh_Hans': '现在就试试！',
    },
    'fpzdkf5c': {
      'en': 'Privacy Policy',
      'es': 'política de privacidad',
      'hi': 'गोपनीयता नीति',
      'tl': 'Patakaran sa Privacy',
      'zh_Hans': '隐私政策',
    },
    'vmjhdnfw': {
      'en': 'Terms of Use',
      'es': 'Condiciones de uso',
      'hi': 'उपयोग की शर्तें',
      'tl': 'Mga Tuntunin ng Paggamit',
      'zh_Hans': '使用条款',
    },
    'oahtqul7': {
      'en': 'Back',
      'es': 'Atrás',
      'hi': 'पीछे',
      'tl': 'Bumalik',
      'zh_Hans': '后退',
    },
    '1vx1fa93': {
      'en': 'About CareerCoach',
      'es': 'Acerca de CareerCoach',
      'hi': 'करियरकोच के बारे में',
      'tl': 'Tungkol sa CareerCoach',
      'zh_Hans': '关于职业教练',
    },
    'utgd415f': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // CareerCoachPage
  {
    'dq5j2vud': {
      'en': 'Career Coach',
      'es': 'Entrenador de carrera',
      'hi': 'कैरियर कोच',
      'tl': 'Career Coach',
      'zh_Hans': '职业教练',
    },
    '9p9akfan': {
      'en':
          'Copy and paste the job advertisement into CareerCoach, and we\'ll analyze your resume-crafted by us or your own-to arm you with insights and confidence-boosting tips to help you secure the job you desire.',
      'es':
          'Copie y pegue el anuncio de trabajo en CareerCoach y analizaremos su currículum (elaborado por nosotros o el suyo propio) para brindarle información y consejos que aumenten su confianza y lo ayuden a conseguir el trabajo que desea.',
      'hi':
          'नौकरी के विज्ञापन को कॉपी करें और CareerCoach में पेस्ट करें, और हम आपके द्वारा या आपके द्वारा तैयार किए गए आपके बायोडाटा का विश्लेषण करेंगे, ताकि आपको आपकी इच्छित नौकरी को सुरक्षित करने में मदद करने के लिए अंतर्दृष्टि और आत्मविश्वास बढ़ाने वाली युक्तियों से लैस किया जा सके।',
      'tl':
          'Kopyahin at i-paste ang advertisement ng trabaho sa CareerCoach, at susuriin namin ang iyong resume na ginawa namin o ng iyong sariling-upang bigyan ka ng mga insight at mga tip sa pagpapalakas ng kumpiyansa upang matulungan kang ma-secure ang trabahong gusto mo.',
      'zh_Hans':
          '将招聘广告复制并粘贴到 CareerCoach 中，我们将分析您由我们或您自己制作的简历，为您提供见解和增强信心的技巧，帮助您获得所需的工作。',
    },
    'z3ovhosq': {
      'en': 'Tap here to learn how it works',
      'es': 'Toca aquí para saber cómo funciona.',
      'hi': 'यह कैसे काम करता है यह जानने के लिए यहां टैप करें',
      'tl': 'Mag-tap dito para matutunan kung paano ito gumagana',
      'zh_Hans': '点击此处了解其工作原理',
    },
    'bgjnqx5l': {
      'en': 'Use url to pate job description',
      'es': 'Utilice la URL para escribir la descripción del trabajo.',
      'hi': 'नौकरी विवरण को पाटने के लिए यूआरएल का उपयोग करें',
      'tl': 'Gumamit ng url upang i-pate ang paglalarawan ng trabaho',
      'zh_Hans': '使用 url 来粘贴职位描述',
    },
    '9gk22vpi': {
      'en': 'Paste the url of job add of interest',
      'es': 'Pegue la URL del anuncio de empleo de su interés.',
      'hi': 'रुचि के अनुसार नौकरी का यूआरएल चिपकाएँ',
      'tl': 'I-paste ang url ng job add of interest',
      'zh_Hans': '粘贴感兴趣的职位添加网址',
    },
    'x6xzwei0': {
      'en': 'Paste url here...',
      'es': 'Pegue la URL aquí...',
      'hi': 'यूआरएल यहां चिपकाएं...',
      'tl': 'Idikit ang url dito...',
      'zh_Hans': '将网址粘贴到此处...',
    },
    '27b7fi21': {
      'en': 'Submit',
      'es': 'Entregar',
      'hi': 'जमा करना',
      'tl': 'Ipasa',
      'zh_Hans': '提交',
    },
    'c6hcxzlw': {
      'en': 'Type in the job title for the job:',
      'es': 'Escriba el título del trabajo para el trabajo:',
      'hi': 'कार्य के लिए कार्य शीर्षक टाइप करें:',
      'tl': 'I-type ang titulo ng trabaho para sa trabaho:',
      'zh_Hans': '输入职位的职位名称：',
    },
    'rs5pcqe0': {
      'en': 'Enter job title...',
      'es': 'Ingrese el título del trabajo...',
      'hi': 'नौकरी का शीर्षक दर्ज करें...',
      'tl': 'Ilagay ang titulo ng trabaho...',
      'zh_Hans': '输入职位名称...',
    },
    'fh0uc7o9': {
      'en': 'Enter job title...',
      'es': 'Ingrese el título del trabajo...',
      'hi': 'नौकरी का शीर्षक दर्ज करें...',
      'tl': 'Ilagay ang titulo ng trabaho...',
      'zh_Hans': '输入职位名称...',
    },
    'x9jg17jl': {
      'en': 'Paste the job details and company info here:',
      'es':
          'Pegue los detalles del trabajo y la información de la empresa aquí:',
      'hi': 'नौकरी का विवरण और कंपनी की जानकारी यहां चिपकाएं:',
      'tl':
          'Idikit ang mga detalye ng trabaho at impormasyon ng kumpanya dito:',
      'zh_Hans': '将职位详细信息和公司信息粘贴到此处：',
    },
    '22fia2rm': {
      'en': 'Paste job description here...',
      'es': 'Pegue la descripción del trabajo aquí...',
      'hi': 'नौकरी का विवरण यहां चिपकाएँ...',
      'tl': 'Idikit ang paglalarawan ng trabaho dito...',
      'zh_Hans': '将职位描述粘贴到此处...',
    },
    'd8phlyr6': {
      'en':
          'Ensure you\'ve copied the entire job description for best results!',
      'es':
          '¡Asegúrese de haber copiado toda la descripción del trabajo para obtener mejores resultados!',
      'hi':
          'सुनिश्चित करें कि आपने सर्वोत्तम परिणामों के लिए संपूर्ण नौकरी विवरण की प्रतिलिपि बना ली है!',
      'tl':
          'Tiyaking nakopya mo ang buong paglalarawan ng trabaho para sa pinakamahusay na mga resulta!',
      'zh_Hans': '确保您已复制整个职位描述以获得最佳结果！',
    },
    'ccldhhqo': {
      'en': 'Continue',
      'es': 'Continuar',
      'hi': 'जारी रखना',
      'tl': 'Magpatuloy',
      'zh_Hans': '继续',
    },
    'm4zj8z3h': {
      'en': 'Now, paste or upload your resume:',
      'es': 'Ahora, pega o sube tu currículum:',
      'hi': 'अब, अपना बायोडाटा चिपकाएँ या अपलोड करें:',
      'tl': 'Ngayon, i-paste o i-upload ang iyong resume:',
      'zh_Hans': '现在，粘贴或上传您的简历：',
    },
    'jv7j0cc3': {
      'en': 'Upload File',
      'es': 'Subir archivo',
      'hi': 'फ़ाइल अपलोड करें',
      'tl': 'Mag-upload ng File',
      'zh_Hans': '上传文件',
    },
    'rg23kjwv': {
      'en': 'View my resume',
      'es': 'Ver mi currículum',
      'hi': 'मेरा बायोडाटा देखें',
      'tl': 'Tingnan ang aking resume',
      'zh_Hans': '查看我的简历',
    },
    '2moghc42': {
      'en': 'Resume...',
      'es': 'Reanudar...',
      'hi': 'फिर शुरू करना...',
      'tl': 'Ipagpatuloy...',
      'zh_Hans': '恢复...',
    },
    'x01z1s5d': {
      'en': 'File uploaded succesfully!!!',
      'es': '¡¡¡Archivo subido exitosamente!!!',
      'hi': 'फ़ाइल सफलतापूर्वक अपलोड हो गई!!!',
      'tl': 'Matagumpay na na-upload ang file!!!',
      'zh_Hans': '文件上传成功！！！',
    },
    'irdsfwq4': {
      'en': 'Get Me Prepped',
      'es': 'Prepárame',
      'hi': 'मुझे तैयार करो',
      'tl': 'Ihanda Mo Ako',
      'zh_Hans': '让我做好准备',
    },
    'y2u2mdrd': {
      'en': 'Find',
      'es': 'Encontrar',
      'hi': 'खोजो',
      'tl': 'Hanapin',
      'zh_Hans': '寻找',
    },
    '83c4u442': {
      'en': 'Coach',
      'es': 'Entrenador',
      'hi': 'प्रशिक्षक',
      'tl': 'coach',
      'zh_Hans': '教练',
    },
    'p3cl53s2': {
      'en': 'Enhance',
      'es': 'Mejorar',
      'hi': 'बढ़ाना',
      'tl': 'Pagandahin',
      'zh_Hans': '提高',
    },
    'vdvi385i': {
      'en': 'Write',
      'es': 'Escribir',
      'hi': 'लिखना',
      'tl': 'Sumulat',
      'zh_Hans': '写',
    },
    'mj6wh6lm': {
      'en': 'Profile',
      'es': 'Perfil',
      'hi': 'प्रोफ़ाइल',
      'tl': 'Profile',
      'zh_Hans': '轮廓',
    },
    'kwlobxb3': {
      'en': 'Coach',
      'es': 'Entrenador',
      'hi': 'प्रशिक्षक',
      'tl': 'coach',
      'zh_Hans': '教练',
    },
  },
  // EditResume
  {
    '4tcrq6dh': {
      'en': 'Title',
      'es': 'Título',
      'hi': 'शीर्षक',
      'tl': 'Pamagat',
      'zh_Hans': '标题',
    },
    '1oskuoj0': {
      'en': 'Resume',
      'es': 'Reanudar',
      'hi': 'फिर शुरू करना',
      'tl': 'Ipagpatuloy',
      'zh_Hans': '恢复',
    },
    'i50g7d2h': {
      'en': 'Edit Your Resume',
      'es': 'Edita tu currículum',
      'hi': 'अपना बायोडाटा संपादित करें',
      'tl': 'I-edit ang Iyong Resume',
      'zh_Hans': '编辑您的简历',
    },
    'ofvxcod0': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // Onboarding1
  {
    'lrgpya2o': {
      'en': 'Welcome to CareerCoach!',
      'es': '¡Bienvenido a CareerCoach!',
      'hi': 'करियरकोच में आपका स्वागत है!',
      'tl': 'Maligayang pagdating sa CareerCoach!',
      'zh_Hans': '欢迎来到职业教练！',
    },
    '3xxw99j4': {
      'en':
          'We\'re here to help you easily navigate the tough job hunting process. \n\nWe\'ll begin by asking you a few questions before you start your journey!',
      'es':
          'Estamos aquí para ayudarle a navegar fácilmente por el difícil proceso de búsqueda de empleo.\n\n¡Comenzaremos haciéndote algunas preguntas antes de comenzar tu viaje!',
      'hi':
          'हम कठिन नौकरी तलाश प्रक्रिया में आसानी से आपकी मदद करने के लिए यहां हैं।\n\nआपकी यात्रा शुरू करने से पहले हम आपसे कुछ प्रश्न पूछकर शुरुआत करेंगे!',
      'tl':
          'Narito kami upang tulungan kang madaling mag-navigate sa mahirap na proseso ng paghahanap ng trabaho.\n\nMagsisimula kami sa pamamagitan ng pagtatanong sa iyo ng ilang mga katanungan bago mo simulan ang iyong paglalakbay!',
      'zh_Hans': '我们随时帮助您轻松应对艰难的求职过程。\n\n在您开始旅程之前，我们将首先问您几个问题！',
    },
    'nh9v8hax': {
      'en': 'Do you have a resume?',
      'es': '¿Tienes un currículum?',
      'hi': 'क्या आपके पास एक संक्षिप्त विवरण है?',
      'tl': 'May resume ka ba?',
      'zh_Hans': '你有简历吗？',
    },
    'dwte5qbv': {
      'en': 'Yes',
      'es': 'Sí',
      'hi': 'हाँ',
      'tl': 'Oo',
      'zh_Hans': '是的',
    },
    '7s1228g6': {
      'en': 'No',
      'es': 'No',
      'hi': 'नहीं',
      'tl': 'Hindi',
      'zh_Hans': '不',
    },
    'bz2hz46l': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // AnalyzeResume
  {
    '11iv8tad': {
      'en': 'Great! Let\'s make it \neven stronger',
      'es': '¡Excelente! Hagámoslo\nincluso más fuerte',
      'hi': 'महान! चलो यह करते हैं\nसे मज़बूत',
      'tl': 'Malaki! Gawin natin\nmas malakas',
      'zh_Hans': '伟大的！让我们来实现吧\n更强大',
    },
    'moarf4aa': {
      'en': 'Upload PDF',
      'es': 'Subir PDF',
      'hi': 'पीडीएफ अपलोड करें',
      'tl': 'Mag-upload ng PDF',
      'zh_Hans': '上传 PDF',
    },
    '2ut1ntil': {
      'en': 'Delete File',
      'es': 'Borrar archivo',
      'hi': 'फ़ाइल नष्ट करें',
      'tl': 'Burahin ang file',
      'zh_Hans': '删除文件',
    },
    'zhgrueyx': {
      'en':
          'If you upload your resume it will paste as plain text; that\'s okay!',
      'es':
          'Si carga su currículum, se pegará como texto sin formato; ¡esta bien!',
      'hi':
          'यदि आप अपना बायोडाटा अपलोड करते हैं तो यह सादे पाठ के रूप में पेस्ट होगा; वह ठीक है!',
      'tl':
          'Kung i-upload mo ang iyong resume ito ay i-paste bilang plain text; ayos lang iyon!',
      'zh_Hans': '如果您上传简历，它将以纯文本形式粘贴；没关系！',
    },
    '4l02lbdy': {
      'en': 'Or paste here:',
      'es': 'O pegar aquí:',
      'hi': 'या यहां पेस्ट करें:',
      'tl': 'O i-paste dito:',
      'zh_Hans': '或者粘贴在这里：',
    },
    'p4dyrfk3': {
      'en': 'Paste your resume here...',
      'es': 'Pega tu currículum aquí...',
      'hi': 'अपना बायोडाटा यहां चिपकाएं...',
      'tl': 'Idikit ang iyong resume dito...',
      'zh_Hans': '将您的简历粘贴到此处...',
    },
    'hxzaxc1q': {
      'en': 'Next',
      'es': 'Próximo',
      'hi': 'अगला',
      'tl': 'Susunod',
      'zh_Hans': '下一个',
    },
    'vm2ueogl': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // Onboarding2
  {
    'oaiaow5k': {
      'en': 'That\'s okay, would you like to write a resume now?',
      'es': 'Está bien, ¿te gustaría escribir un currículum ahora?',
      'hi': 'यह ठीक है, क्या आप अब बायोडाटा लिखना चाहेंगे?',
      'tl': 'Okay lang, gusto mo bang magsulat ng resume ngayon?',
      'zh_Hans': '没关系，你现在想写简历吗？',
    },
    'vb6vfzyc': {
      'en': 'YES, take me to the resume writer',
      'es': 'SÍ, llévame al redactor del currículum.',
      'hi': 'हाँ, मुझे बायोडाटा लेखक के पास ले चलो',
      'tl': 'OO, dalhin mo ako sa resume writer',
      'zh_Hans': '是的，带我去找简历撰写者',
    },
    'enpdoubx': {
      'en': 'NO, take me to the homepage',
      'es': 'NO, llévame a la página de inicio.',
      'hi': 'नहीं, मुझे मुखपृष्ठ पर ले चलो',
      'tl': 'HINDI, dalhin mo ako sa homepage',
      'zh_Hans': '不，带我到主页',
    },
    'dtn91rhl': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // Homepagenew
  {
    'klfc5ner': {
      'en': 'Welcome,\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'lder0xfz': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'zxr19jww': {
      'en':
          'Hello! \nWe are Jumist app team from AstanaIT University! We are happy to see you in our app Jumistapp!',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'g3z7aezi': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // Tooltips
  {
    'j3tmuftn': {
      'en': 'Skip>>',
      'es': 'Saltar>>',
      'hi': 'छोड़ें>>',
      'tl': 'Laktawan >>',
      'zh_Hans': '跳过>>',
    },
    '8nbvffdw': {
      'en':
          'Welcome to CareerCoach!\nLet\'s take a quick tour so you know your way around',
      'es':
          '¡Bienvenido a CareerCoach!\nHagamos un recorrido rápido para que conozcas el lugar.',
      'hi':
          'करियरकोच में आपका स्वागत है!\nआइए एक त्वरित भ्रमण करें ताकि आप अपना रास्ता जान सकें',
      'tl':
          'Maligayang pagdating sa CareerCoach!\nMaglibot tayo nang mabilis para malaman mo ang iyong daan',
      'zh_Hans': '欢迎来到职业教练！\n让我们快速浏览一下，以便您了解周围的情况',
    },
    'ue8h8uun': {
      'en': 'Next',
      'es': 'Próximo',
      'hi': 'अगला',
      'tl': 'Susunod',
      'zh_Hans': '下一个',
    },
    '9castbsa': {
      'en':
          'With the Enhance feature, you can upload or paste your resume and receive tips on how to improve it',
      'es':
          'Con la función Mejorar, puedes cargar o pegar tu currículum y recibir consejos sobre cómo mejorarlo.',
      'hi':
          'एन्हांस सुविधा के साथ, आप अपना बायोडाटा अपलोड या पेस्ट कर सकते हैं और इसे बेहतर बनाने के बारे में सुझाव प्राप्त कर सकते हैं',
      'tl':
          'Gamit ang feature na Enhance, maaari mong i-upload o i-paste ang iyong resume at makatanggap ng mga tip kung paano ito pagbutihin',
      'zh_Hans': '通过增强功能，您可以上传或粘贴您的简历并接收有关如何改进它的提示',
    },
    'cf56ln4y': {
      'en': 'Back',
      'es': 'Atrás',
      'hi': 'पीछे',
      'tl': 'Bumalik',
      'zh_Hans': '后退',
    },
    'vm42t4iv': {
      'en': 'Next',
      'es': 'Próximo',
      'hi': 'अगला',
      'tl': 'Susunod',
      'zh_Hans': '下一个',
    },
    'r8xed6lg': {
      'en':
          'With the Resumer Writer feature, provide very simple details about your work history; CareerCoach will write you an extremely detailed resume',
      'es':
          'Con la función Resumer Writer, proporcione detalles muy simples sobre su historial laboral; CareerCoach le escribirá un currículum extremadamente detallado',
      'hi':
          'रेज़्यूमर राइटर सुविधा के साथ, अपने कार्य इतिहास के बारे में बहुत ही सरल विवरण प्रदान करें; CareerCoach आपको एक अत्यंत विस्तृत बायोडाटा लिखेगा',
      'tl':
          'Gamit ang tampok na Resumer Writer, magbigay ng napakasimpleng mga detalye tungkol sa iyong kasaysayan ng trabaho; Isusulat sa iyo ng CareerCoach ang isang napaka detalyadong resume',
      'zh_Hans': '通过简历撰写功能，提供有关您工作经历的非常简单的详细信息； CareerCoach将为您写一份极其详细的简历',
    },
    '60f8binn': {
      'en': 'Back',
      'es': 'Atrás',
      'hi': 'पीछे',
      'tl': 'Bumalik',
      'zh_Hans': '后退',
    },
    'q6fr9g39': {
      'en': 'Next',
      'es': 'Próximo',
      'hi': 'अगला',
      'tl': 'Susunod',
      'zh_Hans': '下一个',
    },
    'wyemaqjt': {
      'en':
          'CareerCoach will compare your resume to the job you plan to apply to and provide strategies to make sure you stand out',
      'es':
          'CareerCoach comparará su currículum con el trabajo al que planea postularse y le brindará estrategias para asegurarse de que se destaque.',
      'hi':
          'CareerCoach आपके बायोडाटा की तुलना उस नौकरी से करेगा जिसके लिए आप आवेदन करने की योजना बना रहे हैं और यह सुनिश्चित करने के लिए रणनीतियाँ प्रदान करेगा कि आप अलग दिखें',
      'tl':
          'Ihahambing ng CareerCoach ang iyong resume sa trabahong pinaplano mong aplayan at magbibigay ng mga estratehiya upang matiyak na namumukod-tangi ka',
      'zh_Hans': 'CareerCoach 会将您的简历与您计划申请的工作进行比较，并提供策略以确保您脱颖而出',
    },
    'rliunrjt': {
      'en': 'Back',
      'es': 'Atrás',
      'hi': 'पीछे',
      'tl': 'Bumalik',
      'zh_Hans': '后退',
    },
    'yuzvob8b': {
      'en': 'Next',
      'es': 'Próximo',
      'hi': 'अगला',
      'tl': 'Susunod',
      'zh_Hans': '下一个',
    },
    'cnocuj4x': {
      'en':
          'Our Find Jobs feature searches job boards to show you currently open positions. Simply enter a few key words and the location you wish to work',
      'es':
          'Nuestra función Buscar empleo busca bolsas de trabajo para mostrarle los puestos vacantes actualmente. Simplemente ingrese algunas palabras clave y la ubicación donde desea trabajar',
      'hi':
          'हमारी फाइंड जॉब्स सुविधा आपको वर्तमान में रिक्त पदों को दिखाने के लिए जॉब बोर्ड खोजती है। बस कुछ मुख्य शब्द और वह स्थान दर्ज करें जहां आप काम करना चाहते हैं',
      'tl':
          'Ang aming Find Jobs feature ay naghahanap ng mga job board upang ipakita sa iyo ang mga kasalukuyang bukas na posisyon. Maglagay lamang ng ilang mahahalagang salita at ang lokasyong nais mong magtrabaho',
      'zh_Hans': '我们的“查找工作”功能搜索工作委员会，向您显示当前空缺职位。只需输入几个关键词和您希望工作的地点',
    },
    '2e5jsagc': {
      'en': 'Back',
      'es': 'Atrás',
      'hi': 'पीछे',
      'tl': 'Bumalik',
      'zh_Hans': '后退',
    },
    'cjg9ga63': {
      'en': 'Start using CareerCoach',
      'es': 'Comience a utilizar CareerCoach',
      'hi': 'CareerCoach का उपयोग प्रारंभ करें',
      'tl': 'Simulan ang paggamit ng CareerCoach',
      'zh_Hans': '开始使用职业教练',
    },
    'gqr1lycf': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // FindJobs
  {
    '3txx4c6t': {
      'en': 'Find Jobs\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'md1hsgp2': {
      'en': 'Find jobs suitable for you',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'hrg4g5u5': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'eoer97r8': {
      'en': 'Search Jobs',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '35qe11hh': {
      'en': 'Locations',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'wgp6zheq': {
      'en': 'Submit',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '0wdddfbw': {
      'en': 'Find',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // Subscription
  {
    '6sgak5qs': {
      'en': 'What is CareerCoach?',
      'es': '¿Qué es CareerCoach?',
      'hi': 'कैरियरकोच क्या है?',
      'tl': 'Ano ang CareerCoach?',
      'zh_Hans': '什么是职业教练？',
    },
    'xxsrdc8i': {
      'en':
          'Try a 7-day free trial to explore your career-enhancing tools. Land your job and cancel anytime, or stay for just \$4.99/mo. Click \'Start 7-Day Free Trial\' to begin!',
      'es':
          'Pruebe una prueba gratuita de 7 días para explorar sus herramientas para mejorar su carrera. Consiga su trabajo y cancele en cualquier momento, o quédese por solo \$4.99/mes. Haga clic en \'Iniciar prueba gratuita de 7 días\' para comenzar.',
      'hi':
          'अपने करियर को बेहतर बनाने वाले टूल के बारे में जानने के लिए 7 दिनों का निःशुल्क परीक्षण आज़माएँ। अपनी नौकरी पाएं और किसी भी समय रद्द करें, या केवल \$4.99/महीना पर रुकें। आरंभ करने के लिए \'7-दिवसीय निःशुल्क परीक्षण प्रारंभ करें\' पर क्लिक करें!',
      'tl':
          'Subukan ang isang 7-araw na libreng pagsubok upang tuklasin ang iyong mga tool sa pagpapahusay ng karera. Kunin ang iyong trabaho at kanselahin anumang oras, o manatili sa halagang \$4.99/buwan lang. I-click ang \'Start 7-Day Free Trial\' para magsimula!',
      'zh_Hans':
          '尝试 7 天免费试用，探索您的职业提升工具。找到工作并随时取消，或者每月只需 4.99 美元。单击“开始 7 天免费试用”即可开始！',
    },
    'z1l62daw': {
      'en': 'Specific feedback on your resume',
      'es': 'Comentarios específicos sobre su currículum',
      'hi': 'आपके बायोडाटा पर विशिष्ट प्रतिक्रिया',
      'tl': 'Tukoy na feedback sa iyong resume',
      'zh_Hans': '对简历的具体反馈',
    },
    '7i07lb4h': {
      'en': 'A customized cover letter',
      'es': 'Una carta de presentación personalizada',
      'hi': 'एक अनुकूलित कवर पत्र',
      'tl': 'Isang customized na cover letter',
      'zh_Hans': '定制的求职信',
    },
    '95rgas7n': {
      'en': 'Outreach messages',
      'es': 'Mensajes de divulgación',
      'hi': 'आउटरीच संदेश',
      'tl': 'Mga mensahe ng outreach',
      'zh_Hans': '外展信息',
    },
    'wmbdc1t9': {
      'en': 'Interview plan',
      'es': 'Plan de entrevista',
      'hi': 'साक्षात्कार योजना',
      'tl': 'Plano ng panayam',
      'zh_Hans': '面试计划',
    },
    'l2cxkpkl': {
      'en': 'Pre-employment assessment',
      'es': 'Evaluación previa al empleo',
      'hi': 'रोजगार पूर्व मूल्यांकन',
      'tl': 'Pagtatasa bago ang pagtatrabaho',
      'zh_Hans': '聘前评估',
    },
    '5204ajqs': {
      'en': 'Job summary',
      'es': 'Resumen de trabajo',
      'hi': 'नौकरी का सारांश',
      'tl': 'Buod ng trabaho',
      'zh_Hans': '工作总结',
    },
    'zira958j': {
      'en': 'Job sourcing',
      'es': 'Búsqueda de empleo',
      'hi': 'जॉब सोर्सिंग',
      'tl': 'Pagkuha ng trabaho',
      'zh_Hans': '工作寻找',
    },
    '5ef9ljif': {
      'en': 'Start 7 Day Free Trial',
      'es': 'Comience la prueba gratuita de 7 días',
      'hi': '7 दिवसीय निःशुल्क परीक्षण प्रारंभ करें',
      'tl': 'Simulan ang 7 Araw na Libreng Pagsubok',
      'zh_Hans': '开始 7 天免费试用',
    },
    '3cy9pv2x': {
      'en': '\$4.99 a month after the free trial',
      'es': '\$4,99 al mes después de la prueba gratuita',
      'hi': 'निःशुल्क परीक्षण के बाद \$4.99 प्रति माह',
      'tl': '\$4.99 sa isang buwan pagkatapos ng libreng pagsubok',
      'zh_Hans': '免费试用后每月 4.99 美元',
    },
    'iqomptm9': {
      'en': 'Try 7 days for free',
      'es': 'Prueba 7 días gratis',
      'hi': '7 दिन निःशुल्क आज़माएँ',
      'tl': 'Subukan ang 7 araw nang libre',
      'zh_Hans': '免费试用 7 天',
    },
    'pc9388yd': {
      'en': '\$4.99 a month subscription after 7 days',
      'es': 'Suscripción de \$4,99 al mes después de 7 días',
      'hi': '7 दिनों के बाद \$4.99 प्रति माह सदस्यता',
      'tl': '\$4.99 sa isang buwang subscription pagkatapos ng 7 araw',
      'zh_Hans': '7 天后每月订阅 4.99 美元',
    },
    'ic9150p5': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // Interviewbot
  {
    '050vy3bl': {
      'en': 'Home',
      'es': 'Hogar',
      'hi': 'घर',
      'tl': 'Bahay',
      'zh_Hans': '家',
    },
  },
  // SignUpPage1Credentials
  {
    'yws5lte7': {
      'en': 'Jumistapp',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'mt54uhoj': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '7q232nq5': {
      'en': 'Create Account',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '72ubu8mx': {
      'en': 'Let\'s get started by setting up your credentials',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'yjzn8hck': {
      'en': 'Email',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'm1chaabl': {
      'en': 'Password',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '2t6ojwao': {
      'en': 'Re-enter Password',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'nrbenvl1': {
      'en': 'Continue',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'bn7qmv54': {
      'en': 'Already have an account? Sign in',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '0gofivze': {
      'en': 'Privacy Policy',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // SignUpPage4JobExperience
  {
    'wu8z3uq2': {
      'en': 'Jumistapp',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '7dmiee3l': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'fbng0oq1': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'bgomc3e1': {
      'en': 'Let\'s get to know you',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '6ceysebk': {
      'en': 'Job Title',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '5yczwd1w': {
      'en': 'Company Name',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'xpeuk3td': {
      'en': 'Start Date',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ecr315d8': {
      'en': 'End Date',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'nu1ezg49': {
      'en': 'Currently working in the company',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '5f3r0t5v': {
      'en': 'Skills',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'xkzka77a': {
      'en': 'Add More',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'tzcr8sf3': {
      'en': 'Continue',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '6tbpvtb2': {
      'en': 'Added Jobs:',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'r7h5frhj': {
      'en': 'Privacy Policy',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // SignUpPage3PersonalInfo
  {
    'v5yqdpbl': {
      'en': 'Jumistapp',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'wy725z2h': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '033undlf': {
      'en': 'Personal Information',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    't10qdtne': {
      'en': 'Let\'s get to know you',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'iyssvu72': {
      'en': 'Display Name',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '415mna65': {
      'en': 'Phone No.',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'l3w9xqj0': {
      'en': 'D.O.B.',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '201k1x1z': {
      'en': 'Continue',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'w79jlw3e': {
      'en': 'Privacy Policy',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // ResumeWriter2
  {
    '9jqmtzs8': {
      'en': 'Resume Writer\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'lvfewm83': {
      'en': 'Give a fine touch to your resume.',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '1ot040lh': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '4df3i0v7': {
      'en': 'Job Title',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '88ns1bqp': {
      'en': 'Company Name',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'myd20tn4': {
      'en': 'Start Date',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '1fq4uuk4': {
      'en': 'End Date',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'yvcyndfd': {
      'en': 'Skills',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'wcgmauz1': {
      'en': 'Add More',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '6uxbr6uz': {
      'en': 'Go back',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ejyikk5g': {
      'en': 'Enhance',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '98og2o55': {
      'en': 'Enhance',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // Milo1
  {
    'hyer8j15': {
      'en': 'Milo',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'upopxan8': {
      'en': 'Have a virtual interview\nto prepare for your job',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'b9j8b93p': {
      'en': 'Industry',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'o27mynmv': {
      'en': 'Job',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'spn2t5oi': {
      'en': 'Job Level',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'swirt38y': {
      'en': 'Subject',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '5mfomdja': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'w7uazzwt': {
      'en': 'No. of Questions',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'gmxocx5q': {
      'en': 'English',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    's9aodkd9': {
      'en': 'Hindi',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    's99o1t3l': {
      'en': 'Voice of Choice',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'croxrk7a': {
      'en': 'Search for an item...',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'e6udj9dn': {
      'en': 'Let\'s Start',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ngq5lu5x': {
      'en': 'Home',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // Report1
  {
    'ncb2w7tz': {
      'en': 'CareerCoach Report',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'mk7pbq4j': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'igip21xu': {
      'en': 'Job Title',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'worbq79r': {
      'en':
          '*Make sure the job description matches with job you are preparing for.',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '4zidtyt5': {
      'en': 'Paste Job Description',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'taqv9m22': {
      'en': 'Select From Previously Saved Resumes  ',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'tbzzw1z9': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'payjvcu0': {
      'en': 'Or',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '951lzwvw': {
      'en': 'Upload a new resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '4n2b54bp': {
      'en': 'Enhance',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'x4evt2vb': {
      'en': 'Coach',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // ReportResumeOptimised
  {
    'zigs2ing': {
      'en': 'Career Coach Report\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'okbguk84': {
      'en': 'Give a fine touch to your report',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'v9o3fud6': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'lua1h8di': {
      'en': 'Resume\nOptimised',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'p5uafltt': {
      'en': 'Cover\nLetter',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'a710b4pt': {
      'en': 'Outreach\nMessage',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'y2olkszt': {
      'en': 'Interview\nPlan',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'w1pzg379': {
      'en': 'Job\nSummary',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'u4ntsibw': {
      'en': 'Assessm\nent',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'sisx4ji3': {
      'en': 'Search Jobs',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'q0irb95a': {
      'en': 'Resume Optimised',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ja7mmcc3': {
      'en': 'Cover Letter',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '6vl1rt4p': {
      'en': 'Rewrite',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'hr42cj86': {
      'en': 'Outreach Message',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ekcykp4y': {
      'en': 'Rewrite',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '79ebbft4': {
      'en': 'Interview Plan',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '54xaphux': {
      'en': 'Rewrite',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '8erp13a6': {
      'en': 'Job Summary',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'y447jvg2': {
      'en': 'Rewrite',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'k0x86ozo': {
      'en': 'Assessment',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ivad4q27': {
      'en': 'Download as PDF',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'pi46chjo': {
      'en': 'Home',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // Milo2
  {
    'l8zuilan': {
      'en': 'Milo',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'yfqv4jp5': {
      'en': '\nHave a virtual interview\nto prepare for your job',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '3r5ti387': {
      'en': 'Leave',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'q2lvogbt': {
      'en': 'Home',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // ResumeWriter1
  {
    '4afzycml': {
      'en': 'Resume Writer\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '10314oej': {
      'en': 'Give a fine touch to your resume.',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'eqrxf30u': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '4xu63g97': {
      'en': 'Upload a new resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '24431fx5': {
      'en': 'Remove this file',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'soqg7hqa': {
      'en': 'Or',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'g3d7paue': {
      'en': 'Select From Previously Saved Resumes  ',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'tnhh8nht': {
      'en': 'Option 1',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'qj50h19w': {
      'en': 'Enter details manually',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'zag9evuw': {
      'en': 'Write Resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'xn14a15p': {
      'en': 'Write',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // Profile
  {
    'lpdpwd4y': {
      'en': '\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'v0p7mzox': {
      'en': 'Hello World',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'bvp2igae': {
      'en': 'Written Resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'qjxp75e2': {
      'en': 'Career Coach Report',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '35g6eb25': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'idouvzfe': {
      'en': 'Saved Resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '6f4xaddd': {
      'en': 'Career Coach Report',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'qb590d75': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'oipgxj5t': {
      'en': 'Saved Resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'rvnq59xl': {
      'en': 'Written Resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'es22wn8j': {
      'en': 'Edit Profile',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'xje90ujb': {
      'en': 'Log Out',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '7cwhoqw5': {
      'en': 'Home',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // ProfileEdit
  {
    'oc5dntza': {
      'en': 'Upload image',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'dwlkce5g': {
      'en': 'User Name',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'hh27ocpa': {
      'en': 'Email',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'kzs0xtfi': {
      'en': 'D.O.B.',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '96y1x8mu': {
      'en': 'Phone Number',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'iizdx4ni': {
      'en': 'Field is required',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'n832ey2v': {
      'en': 'Please choose an option from the dropdown',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'm60t0z1s': {
      'en': 'Field is required',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'pyd50ssl': {
      'en': 'Please choose an option from the dropdown',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'tedyp14s': {
      'en': 'Field is required',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'cq4w5yv7': {
      'en': 'Please choose an option from the dropdown',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'pwjluq01': {
      'en': 'Submit',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '0qmdtvnp': {
      'en': 'Home',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // ProfileAddJobExperience
  {
    'atrorhi0': {
      'en': 'Job Experience\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '3q3uzb98': {
      'en': 'Let\'s get to know you',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'v0uwcxnu': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '5vq1bi63': {
      'en': 'Job Experience\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'gpe4lmht': {
      'en': 'Let\'s get to know you',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ch8xpjif': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '3ke55n3u': {
      'en': 'Job Title',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'yrx6ko4r': {
      'en': 'Company Name',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'y2obg3ng': {
      'en': 'Start Date',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'xfznp6rs': {
      'en': 'End Date',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'uoo2aint': {
      'en': 'Skills',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '619ge5g1': {
      'en': 'Add more',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'twl65qjh': {
      'en': 'Continue\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'gvxsanz2': {
      'en': 'Home',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // ResumeEnhancerResult
  {
    'yxvncz97': {
      'en': 'Resume Enhancer\n',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '156mlhui': {
      'en': 'Enhance your resume in under a minute',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'uoyb2y6w': {
      'en': 'Job Experience',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'vyo7svvo': {
      'en': 'Resume Revised',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'yjtlwr1j': {
      'en': 'Career Trajectory',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'os74du6w': {
      'en': 'Other Jobs',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'icj24rhf': {
      'en': 'Resume Tips',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'stplvvi1': {
      'en': 'Career Trajectory',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'e6rgyu51': {
      'en': 'Other Jobs',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'bo5oqw79': {
      'en': 'Resume Tips',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'mnl8ydld': {
      'en': 'Resume Revised',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'itisr09j': {
      'en': 'Download as PDF',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'njnuhw8n': {
      'en': 'Home',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // MyResume
  {
    'd5qu0770': {
      'en': 'PDF',
      'es': 'PDF',
      'hi': 'पीडीएफ',
      'tl': 'PDF',
      'zh_Hans': 'PDF',
    },
    'to8s609u': {
      'en': 'Close',
      'es': 'Cerca',
      'hi': 'बंद करना',
      'tl': 'Isara',
      'zh_Hans': '关闭',
    },
  },
  // FileUpload
  {
    'xc8kkney': {
      'en': 'Upload File',
      'es': 'Subir archivo',
      'hi': 'फ़ाइल अपलोड करें',
      'tl': 'Mag-upload ng File',
      'zh_Hans': '上传文件',
    },
    '4fqy1iak': {
      'en': 'Upload your resume',
      'es': 'PDF',
      'hi': 'पीडीएफ',
      'tl': 'PDF',
      'zh_Hans': 'PDF',
    },
  },
  // WorkHistory
  {
    '30p63rch': {
      'en': 'Enter the COMPANY and the dates you worked there:',
      'es': 'Ingrese la EMPRESA y las fechas en que trabajó allí:',
      'hi': 'कंपनी और वहां काम करने की तारीखें दर्ज करें:',
      'tl':
          'Ilagay ang COMPANY at ang mga petsa kung kailan ka nagtrabaho doon:',
      'zh_Hans': '输入公司和您在那里工作的日期：',
    },
    '8p7sc0du': {
      'en': 'Company',
      'es': 'Compañía',
      'hi': 'कंपनी',
      'tl': 'kumpanya',
      'zh_Hans': '公司',
    },
    'fz5bv68a': {
      'en': 'ie Google',
      'es': 'es decir, Google',
      'hi': 'यानी गूगल',
      'tl': 'ie Google',
      'zh_Hans': '即谷歌',
    },
    'yejet9ks': {
      'en': 'Present',
      'es': 'Presente',
      'hi': 'उपस्थित',
      'tl': 'Present',
      'zh_Hans': '展示',
    },
    'r3wmx3pd': {
      'en': 'What JOB TITLE did you have there?',
      'es': '¿Qué puesto de trabajo tenías allí?',
      'hi': 'आपके पास वहां कौन सा कार्य शीर्षक था?',
      'tl': 'Anong JOB TITLE ang mayroon ka doon?',
      'zh_Hans': '你在那里有什么职位？',
    },
    'e3843s75': {
      'en': 'Job Title',
      'es': 'Título profesional',
      'hi': 'नौकरी का नाम',
      'tl': 'Titulo sa trabaho',
      'zh_Hans': '职称',
    },
    'n74883gr': {
      'en': 'ie Project Manager',
      'es': 'es decir, director de proyecto',
      'hi': 'यानी प्रोजेक्ट मैनेजर',
      'tl': 'ibig sabihin, Tagapamahala ng Proyekto',
      'zh_Hans': '即项目经理',
    },
    '1lzgn4s1': {
      'en': 'What SKILLS did you use for this job?',
      'es': '¿Qué HABILIDADES usaste para este trabajo?',
      'hi': 'इस कार्य के लिए आपने कौन से कौशल का उपयोग किया?',
      'tl': 'Anong mga SKILLS ang ginamit mo para sa trabahong ito?',
      'zh_Hans': '你在这份工作中运用了哪些技能？',
    },
    'd3kizt1e': {
      'en': 'Skills',
      'es': 'Habilidades',
      'hi': 'कौशल',
      'tl': 'Mga kasanayan',
      'zh_Hans': '技能',
    },
    '7iqldb2f': {
      'en': 'ie Budgeting, people management, etc...',
      'es': 'es decir, elaboración de presupuestos, gestión de personas, etc.',
      'hi': 'यानी बजट बनाना, लोगों का प्रबंधन, आदि...',
      'tl': 'ie Pagbabadyet, pamamahala ng mga tao, atbp...',
      'zh_Hans': '即预算、人员管理等...',
    },
    '1h38wola': {
      'en': 'Add Job',
      'es': 'Agregar trabajo',
      'hi': 'नौकरी जोड़ें',
      'tl': 'Magdagdag ng Trabaho',
      'zh_Hans': '添加职位',
    },
  },
  // Empty
  {
    'x503zx9g': {
      'en':
          'Enter the title of your resume than tap done on the keyboard. \nTo add jobs, tap the plus icon.',
      'es':
          'Ingrese el título de su currículum y luego toque Listo en el teclado.\nPara agregar trabajos, toque el ícono más.',
      'hi':
          'कीबोर्ड पर टैप करने के बाद अपने बायोडाटा का शीर्षक दर्ज करें।\nनौकरियाँ जोड़ने के लिए प्लस आइकन पर टैप करें।',
      'tl':
          'Ilagay ang pamagat ng iyong resume kaysa i-tap ang tapos na sa keyboard.\nPara magdagdag ng mga trabaho, i-tap ang icon na plus.',
      'zh_Hans': '输入简历的标题，然后点击键盘上的“完成”。\n要添加作业，请点击加号图标。',
    },
  },
  // AddJob
  {
    'f2gh7u4v': {
      'en': 'Label here...',
      'es': 'Etiqueta aquí...',
      'hi': 'यहां लेबल करें...',
      'tl': 'Label dito...',
      'zh_Hans': '在这里标记...',
    },
  },
  // CustomButtons
  {
    'ic7s0w6z': {
      'en': 'Written Resume',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
  // Miscellaneous
  {
    'wru5a9dm': {
      'en': 'Button',
      'es': 'Botón',
      'hi': 'बटन',
      'tl': 'Pindutan',
      'zh_Hans': '按钮',
    },
    'a1p9amwd': {
      'en': 'Label here...',
      'es': 'Etiqueta aquí...',
      'hi': 'यहां लेबल करें...',
      'tl': 'Label dito...',
      'zh_Hans': '在这里标记...',
    },
    '6ud13rjv': {
      'en': 'Submit',
      'es': 'Entregar',
      'hi': 'जमा करना',
      'tl': 'Ipasa',
      'zh_Hans': '提交',
    },
    'jqyjq64n': {
      'en': 'Cancel',
      'es': 'Cancelar',
      'hi': 'रद्द करना',
      'tl': 'Kanselahin',
      'zh_Hans': '取消',
    },
    'ma5lkski': {
      'en': 'Cancel',
      'es': 'Cancelar',
      'hi': 'रद्द करना',
      'tl': 'Kanselahin',
      'zh_Hans': '取消',
    },
    'k7xkgl9k': {
      'en': 'Sign in',
      'es': 'Iniciar sesión',
      'hi': 'दाखिल करना',
      'tl': 'Mag-sign in',
      'zh_Hans': '登入',
    },
    '23yh5jkr': {
      'en': 'Login with Google',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'r4h1nrs1': {
      'en': 'Button',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'houdcebl': {
      'en': 'Button',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'j4z8qnui': {
      'en': 'Button',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '6e38tdd3': {
      'en': 'Download as PDF',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'a0lf45ko': {
      'en': 'To upload a profile photo we need camera permission',
      'es': 'Para subir una foto de perfil necesitamos permiso de la cámara.',
      'hi':
          'प्रोफ़ाइल फ़ोटो अपलोड करने के लिए हमें कैमरे की अनुमति की आवश्यकता होती है',
      'tl':
          'Upang mag-upload ng larawan sa profile kailangan namin ng pahintulot sa camera',
      'zh_Hans': '要上传个人资料照片，我们需要相机权限',
    },
    '0cvugs4y': {
      'en': 'To upload a profile photo we need photo library permission',
      'es':
          'Para subir una foto de perfil necesitamos permiso de la biblioteca de fotos.',
      'hi':
          'प्रोफ़ाइल फ़ोटो अपलोड करने के लिए हमें फ़ोटो लाइब्रेरी की अनुमति की आवश्यकता होती है',
      'tl':
          'Upang mag-upload ng larawan sa profile kailangan namin ng pahintulot sa photo library',
      'zh_Hans': '要上传个人资料照片，我们需要照片库权限',
    },
    'fgofc12u': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '2dspbmbw': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'gz3frxuu': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'cls2s4xe': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'pn6wdrpd': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '2yyky9t4': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'dlyx79tj': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ls5v37c6': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '26uab4i4': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'ynsr4wid': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'olvzgswf': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '58z6nqyk': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'afmtgxa5': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'wmzgiiul': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '1z9xrnga': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'excbwcsm': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '2tdgi7y0': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'f9455104': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '6nis2iuo': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '8qcsl5m8': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'uh2k9ird': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'dweu10cw': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'yvrw538h': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    '1zum9we6': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'xvn3ma2l': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'cie8e7c9': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
    'iu01404q': {
      'en': '',
      'es': '',
      'hi': '',
      'tl': '',
      'zh_Hans': '',
    },
  },
].reduce((a, b) => a..addAll(b));
