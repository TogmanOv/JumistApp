import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

String? cleareExtraSpace(String? text) {
  // replace line breaks to \n from parameter
  if (text == null || text.isEmpty) return null;
  return text.replaceAll(RegExp(r'\n'), ' ');
}

String? cleareExtraSpaceCopy(String? text) {
  // replace line breaks to \n from parameter
  if (text == null || text.isEmpty) return null;
  return text.replaceAll(RegExp(r'\n'), '\n');
}

String? listToString(List<String>? list) {
  // function to return list values into the one string line with comma
  if (list == null || list.isEmpty) return null;
  return list.join(', ');
}

String toOneLine(String text) {
  // function to return text without any extra spaces and remove spaces
  return text.trim().replaceAll(RegExp(r'\s+'), ' ');
}

String? datetimelisttostring(List<DateTime>? datetimelist) {
  // convert list of datetime to string with delimeter
  if (datetimelist == null || datetimelist.isEmpty) return null;
  final formatter = DateFormat('yyyy-MM-dd');
  return datetimelist.map((dateTime) => formatter.format(dateTime)).join('; ');
}

String? clearText(String? text) {
  if (text != null) {
    text = text.replaceAll('"', '');
    text = text.replaceAll("'", '');
  }
  return text;
}
