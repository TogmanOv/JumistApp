import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'analyze_resume_widget.dart' show AnalyzeResumeWidget;
import 'package:flutter/material.dart';

class AnalyzeResumeModel extends FlutterFlowModel<AnalyzeResumeWidget> {
  ///  Local state fields for this page.

  String? text = '';

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Bottom Sheet - FileUpload] action in Button widget.
  String? apiText;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - API (Analyze resume)] action in Button widget.
  ApiCallResponse? apiResult04e;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
