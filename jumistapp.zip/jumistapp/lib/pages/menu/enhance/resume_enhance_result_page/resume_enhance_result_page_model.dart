import '/flutter_flow/flutter_flow_util.dart';
import 'resume_enhance_result_page_widget.dart'
    show ResumeEnhanceResultPageWidget;
import 'package:flutter/material.dart';

class ResumeEnhanceResultPageModel
    extends FlutterFlowModel<ResumeEnhanceResultPageWidget> {
  ///  Local state fields for this page.

  bool saved = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Custom Action - pdfInvoiceDownloadCopy] action in IconButton widget.
  String? link;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
