import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'resume_enhancer_upload_widget.dart' show ResumeEnhancerUploadWidget;
import 'package:flutter/material.dart';

class ResumeEnhancerUploadModel
    extends FlutterFlowModel<ResumeEnhancerUploadWidget> {
  ///  Local state fields for this page.

  String? text = 'null';

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // Stores action output result for [Backend Call - API (pdf)] action in Button widget.
  ApiCallResponse? apiResults6k;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  // Stores action output result for [Backend Call - API (Analyze resume)] action in Button widget.
  ApiCallResponse? apiResult04e;
  // Stores action output result for [Custom Action - pdfInvoiceDownloadCopy] action in Button widget.
  String? linkCopy;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
