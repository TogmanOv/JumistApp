import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/request_manager.dart';

import 'career_coach_results_widget.dart' show CareerCoachResultsWidget;
import 'package:flutter/material.dart';

class CareerCoachResultsModel
    extends FlutterFlowModel<CareerCoachResultsWidget> {
  ///  Local state fields for this page.

  int? index;

  bool saved = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  // State field(s) for PageView widget.
  PageController? pageViewController;

  int get pageViewCurrentIndex => pageViewController != null &&
          pageViewController!.hasClients &&
          pageViewController!.page != null
      ? pageViewController!.page!.round()
      : 0;
  // State field(s) for resumeOptTips widget.
  FocusNode? resumeOptTipsFocusNode;
  TextEditingController? resumeOptTipsTextController;
  String? Function(BuildContext, String?)? resumeOptTipsTextControllerValidator;
  // State field(s) for otherJobsSkills widget.
  FocusNode? otherJobsSkillsFocusNode;
  TextEditingController? otherJobsSkillsTextController;
  String? Function(BuildContext, String?)?
      otherJobsSkillsTextControllerValidator;
  String? _otherJobsSkillsTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'g9wjd1ak' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for coverLetter widget.
  FocusNode? coverLetterFocusNode;
  TextEditingController? coverLetterTextController;
  String? Function(BuildContext, String?)? coverLetterTextControllerValidator;
  String? _coverLetterTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'wq8eu1t2' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for outreachMsg widget.
  FocusNode? outreachMsgFocusNode;
  TextEditingController? outreachMsgTextController;
  String? Function(BuildContext, String?)? outreachMsgTextControllerValidator;
  String? _outreachMsgTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'b9tcu7m1' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for InterviewPlan widget.
  FocusNode? interviewPlanFocusNode;
  TextEditingController? interviewPlanTextController;
  String? Function(BuildContext, String?)? interviewPlanTextControllerValidator;
  String? _interviewPlanTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'f0v5lqsq' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for QuestionAskCompany widget.
  FocusNode? questionAskCompanyFocusNode;
  TextEditingController? questionAskCompanyTextController;
  String? Function(BuildContext, String?)?
      questionAskCompanyTextControllerValidator;
  String? _questionAskCompanyTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'nucjti5c' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for CandidateAssessment widget.
  FocusNode? candidateAssessmentFocusNode;
  TextEditingController? candidateAssessmentTextController;
  String? Function(BuildContext, String?)?
      candidateAssessmentTextControllerValidator;
  String? _candidateAssessmentTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        '3ryleosw' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for JobSummary widget.
  FocusNode? jobSummaryFocusNode;
  TextEditingController? jobSummaryTextController;
  String? Function(BuildContext, String?)? jobSummaryTextControllerValidator;
  String? _jobSummaryTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'whjp60oz' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for CompensationAnalysis widget.
  FocusNode? compensationAnalysisFocusNode;
  TextEditingController? compensationAnalysisTextController;
  String? Function(BuildContext, String?)?
      compensationAnalysisTextControllerValidator;
  String? _compensationAnalysisTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        '8fgk7ohq' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for RoleExpectations widget.
  FocusNode? roleExpectationsFocusNode;
  TextEditingController? roleExpectationsTextController;
  String? Function(BuildContext, String?)?
      roleExpectationsTextControllerValidator;
  String? _roleExpectationsTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'kvls681v' /* Wait for results */,
      );
    }

    return null;
  }

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController11;
  String? Function(BuildContext, String?)? textController11Validator;
  String? _textController11Validator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'v482d78g' /* Wait for results */,
      );
    }

    return null;
  }

  // Stores action output result for [Backend Call - API (Boolean search string)] action in Button widget.
  ApiCallResponse? apiResultt7s;
  // Stores action output result for [Backend Call - Create Document] action in IconButton widget.
  JobResultRecord? jobRes;

  /// Query cache managers for this widget.

  final _ccr1Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr1({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr1Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr1Cache() => _ccr1Manager.clear();
  void clearCcr1CacheKey(String? uniqueKey) =>
      _ccr1Manager.clearRequest(uniqueKey);

  final _ccr11Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr11({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr11Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr11Cache() => _ccr11Manager.clear();
  void clearCcr11CacheKey(String? uniqueKey) =>
      _ccr11Manager.clearRequest(uniqueKey);

  final _ccr2Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr2({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr2Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr2Cache() => _ccr2Manager.clear();
  void clearCcr2CacheKey(String? uniqueKey) =>
      _ccr2Manager.clearRequest(uniqueKey);

  final _ccr3Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr3({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr3Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr3Cache() => _ccr3Manager.clear();
  void clearCcr3CacheKey(String? uniqueKey) =>
      _ccr3Manager.clearRequest(uniqueKey);

  final _ccr4Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr4({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr4Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr4Cache() => _ccr4Manager.clear();
  void clearCcr4CacheKey(String? uniqueKey) =>
      _ccr4Manager.clearRequest(uniqueKey);

  final _ccr5Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr5({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr5Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr5Cache() => _ccr5Manager.clear();
  void clearCcr5CacheKey(String? uniqueKey) =>
      _ccr5Manager.clearRequest(uniqueKey);

  final _ccr61Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr61({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr61Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr61Cache() => _ccr61Manager.clear();
  void clearCcr61CacheKey(String? uniqueKey) =>
      _ccr61Manager.clearRequest(uniqueKey);

  final _ccr62Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr62({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr62Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr62Cache() => _ccr62Manager.clear();
  void clearCcr62CacheKey(String? uniqueKey) =>
      _ccr62Manager.clearRequest(uniqueKey);

  final _ccr63Manager = FutureRequestManager<ApiCallResponse>();
  Future<ApiCallResponse> ccr63({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<ApiCallResponse> Function() requestFn,
  }) =>
      _ccr63Manager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCcr63Cache() => _ccr63Manager.clear();
  void clearCcr63CacheKey(String? uniqueKey) =>
      _ccr63Manager.clearRequest(uniqueKey);

  @override
  void initState(BuildContext context) {
    otherJobsSkillsTextControllerValidator =
        _otherJobsSkillsTextControllerValidator;
    coverLetterTextControllerValidator = _coverLetterTextControllerValidator;
    outreachMsgTextControllerValidator = _outreachMsgTextControllerValidator;
    interviewPlanTextControllerValidator =
        _interviewPlanTextControllerValidator;
    questionAskCompanyTextControllerValidator =
        _questionAskCompanyTextControllerValidator;
    candidateAssessmentTextControllerValidator =
        _candidateAssessmentTextControllerValidator;
    jobSummaryTextControllerValidator = _jobSummaryTextControllerValidator;
    compensationAnalysisTextControllerValidator =
        _compensationAnalysisTextControllerValidator;
    roleExpectationsTextControllerValidator =
        _roleExpectationsTextControllerValidator;
    textController11Validator = _textController11Validator;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    resumeOptTipsFocusNode?.dispose();
    resumeOptTipsTextController?.dispose();

    otherJobsSkillsFocusNode?.dispose();
    otherJobsSkillsTextController?.dispose();

    coverLetterFocusNode?.dispose();
    coverLetterTextController?.dispose();

    outreachMsgFocusNode?.dispose();
    outreachMsgTextController?.dispose();

    interviewPlanFocusNode?.dispose();
    interviewPlanTextController?.dispose();

    questionAskCompanyFocusNode?.dispose();
    questionAskCompanyTextController?.dispose();

    candidateAssessmentFocusNode?.dispose();
    candidateAssessmentTextController?.dispose();

    jobSummaryFocusNode?.dispose();
    jobSummaryTextController?.dispose();

    compensationAnalysisFocusNode?.dispose();
    compensationAnalysisTextController?.dispose();

    roleExpectationsFocusNode?.dispose();
    roleExpectationsTextController?.dispose();

    textFieldFocusNode?.dispose();
    textController11?.dispose();

    /// Dispose query cache managers for this widget.

    clearCcr1Cache();

    clearCcr11Cache();

    clearCcr2Cache();

    clearCcr3Cache();

    clearCcr4Cache();

    clearCcr5Cache();

    clearCcr61Cache();

    clearCcr62Cache();

    clearCcr63Cache();
  }
}
