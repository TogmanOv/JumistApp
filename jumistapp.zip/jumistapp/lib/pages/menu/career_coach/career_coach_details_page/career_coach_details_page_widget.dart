import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart' as actions;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';
import 'career_coach_details_page_model.dart';
export 'career_coach_details_page_model.dart';

class CareerCoachDetailsPageWidget extends StatefulWidget {
  const CareerCoachDetailsPageWidget({
    super.key,
    required this.coach,
  });

  final DocumentReference? coach;

  @override
  State<CareerCoachDetailsPageWidget> createState() =>
      _CareerCoachDetailsPageWidgetState();
}

class _CareerCoachDetailsPageWidgetState
    extends State<CareerCoachDetailsPageWidget> {
  late CareerCoachDetailsPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CareerCoachDetailsPageModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'CareerCoachDetailsPage'});
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<JobResultRecord>(
      stream: JobResultRecord.getDocument(widget.coach!),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: const Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: SpinKitChasingDots(
                  color: Color(0xFF173235),
                  size: 50.0,
                ),
              ),
            ),
          );
        }
        final careerCoachDetailsPageJobResultRecord = snapshot.data!;
        return GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: WillPopScope(
            onWillPop: () async => false,
            child: Scaffold(
              key: scaffoldKey,
              backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
              floatingActionButton: FloatingActionButton(
                onPressed: () async {
                  logFirebaseEvent('CAREER_COACH_DETAILS_FloatingActionButto');
                },
                backgroundColor: Colors.black,
                elevation: 8.0,
                child: FlutterFlowIconButton(
                  borderRadius: 20.0,
                  borderWidth: 1.0,
                  buttonSize: 40.0,
                  icon: Icon(
                    FFIcons.kshareOutline,
                    color: FlutterFlowTheme.of(context).primaryBackground,
                    size: 24.0,
                  ),
                  showLoadingIndicator: true,
                  onPressed: () async {
                    logFirebaseEvent(
                        'CAREER_COACH_DETAILS_shareOutline_ICN_ON');
                    logFirebaseEvent('IconButton_firestore_query');
                    _model.reports = await queryResultsRecordOnce(
                      parent: widget.coach,
                    );
                    logFirebaseEvent('IconButton_custom_action');
                    _model.pdf = await actions.pdfInvoiceDownloadReport(
                      context,
                      _model.reports
                          ?.where(
                              (e) => e.coachType == 'Resume Optimization Tips')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) =>
                              e.coachType ==
                              'Other Jobs That Match Your Skills')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) => e.coachType == 'Cover Letter')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) => e.coachType == 'Outreach Messages')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) => e.coachType == 'Interview Plan')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) =>
                              e.coachType ==
                              'Questions You Can Ask the Company')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) => e.coachType == 'Candidate Assessment')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) => e.coachType == 'Job Summary')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) => e.coachType == 'Compensation Analysis')
                          .toList()
                          .first
                          .result,
                      _model.reports
                          ?.where((e) => e.coachType == 'Role Expectations')
                          .toList()
                          .first
                          .result,
                    );
                    logFirebaseEvent('IconButton_launch_u_r_l');
                    await launchURL(_model.pdf!);

                    setState(() {});
                  },
                ),
              ),
              appBar: AppBar(
                backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
                automaticallyImplyLeading: false,
                leading: FlutterFlowIconButton(
                  borderColor: Colors.transparent,
                  borderRadius: 30.0,
                  borderWidth: 1.0,
                  buttonSize: 60.0,
                  icon: Icon(
                    Icons.arrow_back_rounded,
                    color: FlutterFlowTheme.of(context).primaryText,
                    size: 30.0,
                  ),
                  onPressed: () async {
                    logFirebaseEvent(
                        'CAREER_COACH_DETAILS_arrow_back_rounded_');
                    logFirebaseEvent('IconButton_navigate_back');
                    context.pop();
                  },
                ),
                title: GradientText(
                  careerCoachDetailsPageJobResultRecord.jobTitle,
                  style: FlutterFlowTheme.of(context).headlineMedium.override(
                        fontFamily: 'SF Pro',
                        color: FlutterFlowTheme.of(context).primaryText,
                        fontSize: 22.0,
                        letterSpacing: 0.0,
                        useGoogleFonts: false,
                      ),
                  colors: const [
                    Color(0xFF173235),
                    Color(0xFF106967),
                    Color(0xFF4FBC9B),
                    Color(0xFF32BFD9),
                    Color(0xFFEFCA7D)
                  ],
                  gradientDirection: GradientDirection.ltr,
                  gradientType: GradientType.linear,
                ),
                actions: const [],
                centerTitle: false,
                elevation: 0.0,
              ),
              body: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 12.0, 0.0, 12.0),
                              child: Material(
                                color: Colors.transparent,
                                elevation: 1.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Container(
                                  width: 300.0,
                                  height: 600.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        12.0, 0.0, 12.0, 0.0),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'f1wyn036' /* Resume Optimization Tips */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo:
                                                    'Resume Optimization Tips',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              '9dbkhwti' /* Other Jobs That Match Your Ski... */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo:
                                                    'Other Jobs That Match Your Skills',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                        ]
                                            .divide(const SizedBox(height: 6.0))
                                            .addToStart(const SizedBox(height: 12.0))
                                            .addToEnd(const SizedBox(height: 12.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 12.0, 0.0, 12.0),
                              child: Material(
                                color: Colors.transparent,
                                elevation: 1.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Container(
                                  width: 300.0,
                                  height: 600.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        12.0, 0.0, 12.0, 0.0),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'um1zq9q5' /* Cover Letter */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsetsDirectional.fromSTEB(
                                                    10.0, 0.0, 10.0, 0.0),
                                            child: Text(
                                              FFLocalizations.of(context)
                                                  .getText(
                                                '05niohec' /* Be sure to proofread for accur... */,
                                              ),
                                              style: FlutterFlowTheme.of(
                                                      context)
                                                  .bodyMedium
                                                  .override(
                                                    fontFamily: 'SF Pro',
                                                    letterSpacing: 0.0,
                                                    fontWeight: FontWeight.bold,
                                                    fontStyle: FontStyle.italic,
                                                    useGoogleFonts: false,
                                                  ),
                                            ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo: 'Cover Letter',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                        ]
                                            .divide(const SizedBox(height: 6.0))
                                            .addToStart(const SizedBox(height: 12.0))
                                            .addToEnd(const SizedBox(height: 12.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 12.0, 0.0, 12.0),
                              child: Material(
                                color: Colors.transparent,
                                elevation: 1.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Container(
                                  width: 300.0,
                                  height: 600.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        12.0, 0.0, 12.0, 0.0),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'x6veaz3m' /* Outreach Messages */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo: 'Outreach Messages',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                        ]
                                            .divide(const SizedBox(height: 6.0))
                                            .addToStart(const SizedBox(height: 12.0))
                                            .addToEnd(const SizedBox(height: 12.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 12.0, 0.0, 12.0),
                              child: Material(
                                color: Colors.transparent,
                                elevation: 1.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Container(
                                  width: 300.0,
                                  height: 600.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        12.0, 0.0, 12.0, 0.0),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'b8n85pe0' /* Interview Plan */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo: 'Interview Plan',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'illatvob' /* Questions You Can Ask the Comp... */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo:
                                                    'Questions You Can Ask the Company',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                        ]
                                            .divide(const SizedBox(height: 6.0))
                                            .addToStart(const SizedBox(height: 12.0))
                                            .addToEnd(const SizedBox(height: 12.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 12.0, 0.0, 12.0),
                              child: Material(
                                color: Colors.transparent,
                                elevation: 1.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Container(
                                  width: 300.0,
                                  height: 600.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        12.0, 0.0, 12.0, 0.0),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'njb8w5g8' /* Candidate Assessment */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo:
                                                    'Candidate Assessment',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                        ]
                                            .divide(const SizedBox(height: 6.0))
                                            .addToStart(const SizedBox(height: 12.0))
                                            .addToEnd(const SizedBox(height: 12.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  12.0, 12.0, 0.0, 12.0),
                              child: Material(
                                color: Colors.transparent,
                                elevation: 1.0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                ),
                                child: Container(
                                  width: 300.0,
                                  height: 600.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    borderRadius: BorderRadius.circular(12.0),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsetsDirectional.fromSTEB(
                                        12.0, 0.0, 12.0, 0.0),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              '1wl4sjpk' /* Job Summary */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo: 'Job Summary',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'o17zmw7n' /* Compensation Analysis */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo:
                                                    'Compensation Analysis',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'n7xy9k5n' /* Role Expectations */,
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .headlineSmall
                                                .override(
                                                  fontFamily: 'SF Pro',
                                                  letterSpacing: 0.0,
                                                  useGoogleFonts: false,
                                                ),
                                          ),
                                          StreamBuilder<List<ResultsRecord>>(
                                            stream: queryResultsRecord(
                                              parent: widget.coach,
                                              queryBuilder: (resultsRecord) =>
                                                  resultsRecord.where(
                                                'coach_type',
                                                isEqualTo: 'Role Expectations',
                                              ),
                                              singleRecord: true,
                                            ),
                                            builder: (context, snapshot) {
                                              // Customize what your widget looks like when it's loading.
                                              if (!snapshot.hasData) {
                                                return const Center(
                                                  child: SizedBox(
                                                    width: 50.0,
                                                    height: 50.0,
                                                    child: SpinKitChasingDots(
                                                      color: Color(0xFF173235),
                                                      size: 50.0,
                                                    ),
                                                  ),
                                                );
                                              }
                                              List<ResultsRecord>
                                                  textResultsRecordList =
                                                  snapshot.data!;
                                              // Return an empty Container when the item does not exist.
                                              if (snapshot.data!.isEmpty) {
                                                return Container();
                                              }
                                              final textResultsRecord =
                                                  textResultsRecordList
                                                          .isNotEmpty
                                                      ? textResultsRecordList
                                                          .first
                                                      : null;
                                              return AutoSizeText(
                                                textResultsRecord!.result,
                                                textAlign: TextAlign.start,
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .labelLarge
                                                        .override(
                                                          fontFamily: 'SF Pro',
                                                          letterSpacing: 0.0,
                                                          useGoogleFonts: false,
                                                        ),
                                              );
                                            },
                                          ),
                                        ]
                                            .divide(const SizedBox(height: 6.0))
                                            .addToStart(const SizedBox(height: 12.0))
                                            .addToEnd(const SizedBox(height: 12.0)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ].addToEnd(const SizedBox(width: 12.0)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
