import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/actions/index.dart' as actions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'work_history_model.dart';
export 'work_history_model.dart';

class WorkHistoryWidget extends StatefulWidget {
  const WorkHistoryWidget({super.key});

  @override
  State<WorkHistoryWidget> createState() => _WorkHistoryWidgetState();
}

class _WorkHistoryWidgetState extends State<WorkHistoryWidget> {
  late WorkHistoryModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => WorkHistoryModel());

    _model.textController1 ??= TextEditingController();
    _model.textFieldFocusNode1 ??= FocusNode();

    _model.textController2 ??= TextEditingController();
    _model.textFieldFocusNode2 ??= FocusNode();

    _model.textController3 ??= TextEditingController();
    _model.textFieldFocusNode3 ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: Container(
            width: double.infinity,
            height: 410.0,
            decoration: const BoxDecoration(
              color: Colors.white,
            ),
            child: Form(
              key: _model.formKey,
              autovalidateMode: AutovalidateMode.disabled,
              child: Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 0.0, 10.0),
                      child: Text(
                        FFLocalizations.of(context).getText(
                          '30p63rch' /* Enter the COMPANY and the date... */,
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'SF Pro',
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                8.0, 0.0, 8.0, 0.0),
                            child: TextFormField(
                              controller: _model.textController1,
                              focusNode: _model.textFieldFocusNode1,
                              onChanged: (_) => EasyDebounce.debounce(
                                '_model.textController1',
                                const Duration(milliseconds: 5000),
                                () => setState(() {}),
                              ),
                              autofocus: true,
                              textInputAction: TextInputAction.done,
                              obscureText: false,
                              decoration: InputDecoration(
                                labelText: FFLocalizations.of(context).getText(
                                  '8p7sc0du' /* Company */,
                                ),
                                labelStyle: FlutterFlowTheme.of(context)
                                    .labelMedium
                                    .override(
                                      fontFamily: 'SF Pro',
                                      letterSpacing: 0.0,
                                      useGoogleFonts: false,
                                    ),
                                hintText: FFLocalizations.of(context).getText(
                                  'fz5bv68a' /* ie Google */,
                                ),
                                hintStyle: FlutterFlowTheme.of(context)
                                    .labelMedium
                                    .override(
                                      fontFamily: 'SF Pro',
                                      letterSpacing: 0.0,
                                      fontStyle: FontStyle.italic,
                                      useGoogleFonts: false,
                                    ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color:
                                        FlutterFlowTheme.of(context).alternate,
                                    width: 2.0,
                                  ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                    color: Color(0xFF173235),
                                    width: 2.0,
                                  ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: FlutterFlowTheme.of(context).error,
                                    width: 2.0,
                                  ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                focusedErrorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: FlutterFlowTheme.of(context).error,
                                    width: 2.0,
                                  ),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'SF Pro',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                              validator: _model.textController1Validator
                                  .asValidator(context),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 5.0, 0.0),
                            child: FlutterFlowIconButton(
                              borderRadius: 20.0,
                              borderWidth: 1.0,
                              buttonSize: 40.0,
                              fillColor: const Color(0xFF173235),
                              icon: Icon(
                                Icons.edit_calendar,
                                color: FlutterFlowTheme.of(context).borderColor,
                                size: 24.0,
                              ),
                              onPressed: () async {
                                logFirebaseEvent(
                                    'WORK_HISTORY_edit_calendar_ICN_ON_TAP');
                                logFirebaseEvent('IconButton_custom_action');
                                _model.dateFrom = await actions.monthYearPicker(
                                  context,
                                );

                                setState(() {});
                              },
                            ),
                          ),
                          Text(
                            '${dateTimeFormat(
                              'M.y',
                              _model.dateFrom,
                              locale: FFLocalizations.of(context).languageCode,
                            )} - ',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'SF Pro',
                                  letterSpacing: 0.0,
                                  useGoogleFonts: false,
                                ),
                          ),
                          if (valueOrDefault<bool>(
                            _model.checkboxValue == false,
                            false,
                          ))
                            Text(
                              dateTimeFormat(
                                'M.y',
                                _model.dateTo,
                                locale:
                                    FFLocalizations.of(context).languageCode,
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'SF Pro',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                            ),
                          Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                5.0, 0.0, 15.0, 0.0),
                            child: FlutterFlowIconButton(
                              borderRadius: 20.0,
                              borderWidth: 1.0,
                              buttonSize: 40.0,
                              fillColor: const Color(0xFF173235),
                              disabledColor: const Color(0x8A000000),
                              disabledIconColor:
                                  FlutterFlowTheme.of(context).primaryText,
                              icon: Icon(
                                Icons.edit_calendar,
                                color: FlutterFlowTheme.of(context).borderColor,
                                size: 24.0,
                              ),
                              onPressed: (_model.checkboxValue == true)
                                  ? null
                                  : () async {
                                      logFirebaseEvent(
                                          'WORK_HISTORY_edit_calendar_ICN_ON_TAP');
                                      logFirebaseEvent(
                                          'IconButton_custom_action');
                                      _model.dateTo =
                                          await actions.monthYearPicker(
                                        context,
                                      );
                                      logFirebaseEvent(
                                          'IconButton_update_component_state');
                                      setState(() {
                                        _model.dateToState = _model.dateTo;
                                      });

                                      setState(() {});
                                    },
                            ),
                          ),
                          Theme(
                            data: ThemeData(
                              checkboxTheme: CheckboxThemeData(
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize:
                                    MaterialTapTargetSize.shrinkWrap,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4.0),
                                ),
                              ),
                              unselectedWidgetColor:
                                  FlutterFlowTheme.of(context).secondaryText,
                            ),
                            child: Checkbox(
                              value: _model.checkboxValue ??= false,
                              onChanged: (newValue) async {
                                setState(
                                    () => _model.checkboxValue = newValue!);
                                if (newValue!) {
                                  logFirebaseEvent(
                                      'WORK_HISTORY_Checkbox_wewa2ndj_ON_TOGGLE');
                                  logFirebaseEvent(
                                      'Checkbox_update_component_state');
                                  setState(() {
                                    _model.dateToState = getCurrentTimestamp;
                                  });
                                }
                              },
                              side: BorderSide(
                                width: 2,
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                              ),
                              activeColor: const Color(0xFF173235),
                              checkColor: FlutterFlowTheme.of(context).info,
                            ),
                          ),
                          Text(
                            FFLocalizations.of(context).getText(
                              'yejet9ks' /* Present */,
                            ),
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'SF Pro',
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.normal,
                                  useGoogleFonts: false,
                                ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(8.0, 12.0, 0.0, 10.0),
                      child: Text(
                        FFLocalizations.of(context).getText(
                          'r3wmx3pd' /* What JOB TITLE did you have th... */,
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'SF Pro',
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 0.0),
                      child: TextFormField(
                        controller: _model.textController2,
                        focusNode: _model.textFieldFocusNode2,
                        autofocus: true,
                        textInputAction: TextInputAction.done,
                        obscureText: false,
                        decoration: InputDecoration(
                          labelText: FFLocalizations.of(context).getText(
                            'e3843s75' /* Job Title */,
                          ),
                          labelStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'SF Pro',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                          hintText: FFLocalizations.of(context).getText(
                            'n74883gr' /* ie Project Manager */,
                          ),
                          hintStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'SF Pro',
                                    letterSpacing: 0.0,
                                    fontStyle: FontStyle.italic,
                                    useGoogleFonts: false,
                                  ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).alternate,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              color: Color(0xFF173235),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'SF Pro',
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                        validator: _model.textController2Validator
                            .asValidator(context),
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(8.0, 12.0, 0.0, 10.0),
                      child: Text(
                        FFLocalizations.of(context).getText(
                          '1lzgn4s1' /* What SKILLS did you use for th... */,
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'SF Pro',
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 0.0),
                      child: TextFormField(
                        controller: _model.textController3,
                        focusNode: _model.textFieldFocusNode3,
                        autofocus: true,
                        textInputAction: TextInputAction.done,
                        obscureText: false,
                        decoration: InputDecoration(
                          labelText: FFLocalizations.of(context).getText(
                            'd3kizt1e' /* Skills */,
                          ),
                          labelStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'SF Pro',
                                    letterSpacing: 0.0,
                                    useGoogleFonts: false,
                                  ),
                          hintText: FFLocalizations.of(context).getText(
                            '7iqldb2f' /* ie Budgeting, people managemen... */,
                          ),
                          hintStyle:
                              FlutterFlowTheme.of(context).labelMedium.override(
                                    fontFamily: 'SF Pro',
                                    letterSpacing: 0.0,
                                    fontStyle: FontStyle.italic,
                                    useGoogleFonts: false,
                                  ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).alternate,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              color: Color(0xFF173235),
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).error,
                              width: 2.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'SF Pro',
                              letterSpacing: 0.0,
                              useGoogleFonts: false,
                            ),
                        validator: _model.textController3Validator
                            .asValidator(context),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [
                              Color(0xFF173235),
                              Color(0xFF106967),
                              Color(0xFF4FBC9B),
                              Color(0xFF32BFD9),
                              Color(0xFFEFCA7D)
                            ],
                            stops: [0.0, 0.0, 0.0, 0.5, 1.0],
                            begin: AlignmentDirectional(0.0, -1.0),
                            end: AlignmentDirectional(0, 1.0),
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: FFButtonWidget(
                          onPressed: !((_model.textController1.text != '') &&
                                  (_model.textController2.text != '') &&
                                  (_model.textController3.text != '') &&
                                  (_model.dateFrom != null) &&
                                  ((_model.dateTo != null) ||
                                      _model.checkboxValue!))
                              ? null
                              : () async {
                                  logFirebaseEvent(
                                      'WORK_HISTORY_COMP_ADD_JOB_BTN_ON_TAP');
                                  logFirebaseEvent('Button_validate_form');
                                  if (_model.formKey.currentState == null ||
                                      !_model.formKey.currentState!
                                          .validate()) {
                                    return;
                                  }
                                  if ((_model.dateFrom != null) &&
                                      ((_model.dateTo != null) ||
                                          (_model.checkboxValue == true)) &&
                                      (_model.textController1.text != '') &&
                                      (_model.textController2.text != '') &&
                                      (_model.textController3.text != '')) {
                                    if (_model.dateFrom! <
                                        _model.dateToState!) {
                                      if (_model.checkboxValue == true) {
                                        logFirebaseEvent('Button_backend_call');

                                        var workhistoryRecordReference1 =
                                            WorkhistoryRecord.createDoc(
                                                currentUserReference!);
                                        await workhistoryRecordReference1
                                            .set(createWorkhistoryRecordData(
                                          jobname: _model.textController2.text,
                                          skills: _model.textController3.text,
                                          company: _model.textController1.text,
                                          dates: '${dateTimeFormat(
                                            'M.y',
                                            _model.dateFrom,
                                            locale: FFLocalizations.of(context)
                                                .languageCode,
                                          )}-${dateTimeFormat(
                                            'M.y',
                                            getCurrentTimestamp,
                                            locale: FFLocalizations.of(context)
                                                .languageCode,
                                          )}',
                                          dateFrom: _model.dateFrom,
                                          dateTo: getCurrentTimestamp,
                                        ));
                                        _model.first = WorkhistoryRecord
                                            .getDocumentFromData(
                                                createWorkhistoryRecordData(
                                                  jobname: _model
                                                      .textController2.text,
                                                  skills: _model
                                                      .textController3.text,
                                                  company: _model
                                                      .textController1.text,
                                                  dates: '${dateTimeFormat(
                                                    'M.y',
                                                    _model.dateFrom,
                                                    locale: FFLocalizations.of(
                                                            context)
                                                        .languageCode,
                                                  )}-${dateTimeFormat(
                                                    'M.y',
                                                    getCurrentTimestamp,
                                                    locale: FFLocalizations.of(
                                                            context)
                                                        .languageCode,
                                                  )}',
                                                  dateFrom: _model.dateFrom,
                                                  dateTo: getCurrentTimestamp,
                                                ),
                                                workhistoryRecordReference1);
                                        logFirebaseEvent(
                                            'Button_update_app_state');
                                        FFAppState().addToJobs(
                                            _model.textController2.text);
                                        FFAppState().addToCompanies(
                                            _model.textController1.text);
                                        FFAppState().addToSkills(
                                            _model.textController3.text);
                                        FFAppState()
                                            .addToDates(_model.first!.dates);
                                      } else {
                                        logFirebaseEvent('Button_backend_call');

                                        var workhistoryRecordReference2 =
                                            WorkhistoryRecord.createDoc(
                                                currentUserReference!);
                                        await workhistoryRecordReference2
                                            .set(createWorkhistoryRecordData(
                                          jobname: _model.textController2.text,
                                          skills: _model.textController3.text,
                                          company: _model.textController1.text,
                                          dates: '${valueOrDefault<String>(
                                            dateTimeFormat(
                                              'M.y',
                                              _model.dateFrom,
                                              locale:
                                                  FFLocalizations.of(context)
                                                      .languageCode,
                                            ),
                                            'M.y',
                                          )}-${dateTimeFormat(
                                            'M.y',
                                            _model.dateTo,
                                            locale: FFLocalizations.of(context)
                                                .languageCode,
                                          )}',
                                          dateFrom: _model.dateFrom,
                                          dateTo: _model.dateTo,
                                        ));
                                        _model.second = WorkhistoryRecord
                                            .getDocumentFromData(
                                                createWorkhistoryRecordData(
                                                  jobname: _model
                                                      .textController2.text,
                                                  skills: _model
                                                      .textController3.text,
                                                  company: _model
                                                      .textController1.text,
                                                  dates:
                                                      '${valueOrDefault<String>(
                                                    dateTimeFormat(
                                                      'M.y',
                                                      _model.dateFrom,
                                                      locale:
                                                          FFLocalizations.of(
                                                                  context)
                                                              .languageCode,
                                                    ),
                                                    'M.y',
                                                  )}-${dateTimeFormat(
                                                    'M.y',
                                                    _model.dateTo,
                                                    locale: FFLocalizations.of(
                                                            context)
                                                        .languageCode,
                                                  )}',
                                                  dateFrom: _model.dateFrom,
                                                  dateTo: _model.dateTo,
                                                ),
                                                workhistoryRecordReference2);
                                        logFirebaseEvent(
                                            'Button_update_app_state');
                                        FFAppState().addToJobs(
                                            _model.textController2.text);
                                        FFAppState().addToCompanies(
                                            _model.textController1.text);
                                        FFAppState().addToSkills(
                                            _model.textController3.text);
                                        FFAppState()
                                            .addToDates(_model.second!.dates);
                                      }

                                      logFirebaseEvent('Button_bottom_sheet');
                                      Navigator.pop(context);
                                    } else {
                                      logFirebaseEvent('Button_alert_dialog');
                                      await showDialog(
                                        context: context,
                                        builder: (alertDialogContext) {
                                          return WebViewAware(
                                            child: AlertDialog(
                                              title:
                                                  const Text('Set dates correctly'),
                                              actions: [
                                                TextButton(
                                                  onPressed: () =>
                                                      Navigator.pop(
                                                          alertDialogContext),
                                                  child: const Text('Ok'),
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      );
                                    }
                                  } else {
                                    logFirebaseEvent('Button_alert_dialog');
                                    await showDialog(
                                      context: context,
                                      builder: (alertDialogContext) {
                                        return WebViewAware(
                                          child: AlertDialog(
                                            title: const Text('Fill all values'),
                                            actions: [
                                              TextButton(
                                                onPressed: () => Navigator.pop(
                                                    alertDialogContext),
                                                child: const Text('Ok'),
                                              ),
                                            ],
                                          ),
                                        );
                                      },
                                    );
                                  }

                                  setState(() {});
                                },
                          text: FFLocalizations.of(context).getText(
                            '1h38wola' /* Add Job */,
                          ),
                          options: FFButtonOptions(
                            height: 40.0,
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                24.0, 0.0, 24.0, 0.0),
                            iconPadding: const EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: const Color(0x00FFFFFF),
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'SF Pro',
                                  color: Colors.white,
                                  letterSpacing: 0.0,
                                  useGoogleFonts: false,
                                ),
                            elevation: 0.0,
                            borderSide: const BorderSide(
                              color: Colors.transparent,
                              width: 1.0,
                            ),
                            borderRadius: BorderRadius.circular(8.0),
                            disabledColor: const Color(0x8A000000),
                            disabledTextColor: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
