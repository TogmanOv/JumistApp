import '/flutter_flow/flutter_flow_util.dart';
import 'interviewbot_widget.dart' show InterviewbotWidget;
import 'package:flutter/material.dart';

class InterviewbotModel extends FlutterFlowModel<InterviewbotWidget> {
  ///  Local state fields for this page.

  bool isRecording = false;

  bool isSpeaking = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
