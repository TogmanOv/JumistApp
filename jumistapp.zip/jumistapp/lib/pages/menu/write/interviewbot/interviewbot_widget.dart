import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';
import 'interviewbot_model.dart';
export 'interviewbot_model.dart';

class InterviewbotWidget extends StatefulWidget {
  const InterviewbotWidget({super.key});

  @override
  State<InterviewbotWidget> createState() => _InterviewbotWidgetState();
}

class _InterviewbotWidgetState extends State<InterviewbotWidget>
    with TickerProviderStateMixin {
  late InterviewbotModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InterviewbotModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'Interviewbot'});
    animationsMap.addAll({
      'lottieAnimationOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 1.ms),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'conditionalBuilderOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 1.ms),
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: Stack(
            children: [
              Align(
                alignment: const AlignmentDirectional(0.0, 0.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).borderColor,
                        borderRadius: BorderRadius.circular(24.0),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(32.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (_model.isSpeaking)
                              Lottie.asset(
                                'assets/lottie_animations/Animation_-_1704731435374.json',
                                width: 400.0,
                                height: 200.0,
                                fit: BoxFit.cover,
                                animate: true,
                              ).animateOnPageLoad(animationsMap[
                                  'lottieAnimationOnPageLoadAnimation']!),
                            if (!_model.isSpeaking)
                              Builder(
                                builder: (context) {
                                  if (_model.isRecording) {
                                    return FlutterFlowIconButton(
                                      borderColor:
                                          FlutterFlowTheme.of(context).primary,
                                      borderRadius: 100.0,
                                      borderWidth: 1.0,
                                      buttonSize: 200.0,
                                      fillColor:
                                          FlutterFlowTheme.of(context).accent1,
                                      icon: Icon(
                                        Icons.stop_rounded,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 80.0,
                                      ),
                                      showLoadingIndicator: true,
                                      onPressed: () async {
                                        logFirebaseEvent(
                                            'INTERVIEWBOT_stop_rounded_ICN_ON_TAP');
                                        logFirebaseEvent(
                                            'IconButton_update_page_state');
                                        setState(() {
                                          _model.isRecording = false;
                                        });
                                      },
                                    );
                                  } else {
                                    return FlutterFlowIconButton(
                                      borderColor:
                                          FlutterFlowTheme.of(context).primary,
                                      borderRadius: 100.0,
                                      borderWidth: 1.0,
                                      buttonSize: 200.0,
                                      fillColor:
                                          FlutterFlowTheme.of(context).accent1,
                                      icon: Icon(
                                        Icons.mic_none,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 80.0,
                                      ),
                                      showLoadingIndicator: true,
                                      onPressed: () async {
                                        logFirebaseEvent(
                                            'INTERVIEWBOT_PAGE_mic_none_ICN_ON_TAP');
                                        logFirebaseEvent(
                                            'IconButton_update_page_state');
                                        setState(() {
                                          _model.isRecording = true;
                                        });
                                      },
                                    );
                                  }
                                },
                              ).animateOnPageLoad(animationsMap[
                                  'conditionalBuilderOnPageLoadAnimation']!),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: const AlignmentDirectional(0.0, 1.0),
                child: Container(
                  width: double.infinity,
                  height: 60.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).borderColor,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
