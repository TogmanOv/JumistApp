import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/request_manager.dart';

import 'resume_writer_widget.dart' show ResumeWriterWidget;
import 'package:flutter/material.dart';

class ResumeWriterModel extends FlutterFlowModel<ResumeWriterWidget> {
  ///  Local state fields for this page.

  List<String> skills = [];
  void addToSkills(String item) => skills.add(item);
  void removeFromSkills(String item) => skills.remove(item);
  void removeAtIndexFromSkills(int index) => skills.removeAt(index);
  void insertAtIndexInSkills(int index, String item) =>
      skills.insert(index, item);
  void updateSkillsAtIndex(int index, Function(String) updateFn) =>
      skills[index] = updateFn(skills[index]);

  List<String> jobs = [];
  void addToJobs(String item) => jobs.add(item);
  void removeFromJobs(String item) => jobs.remove(item);
  void removeAtIndexFromJobs(int index) => jobs.removeAt(index);
  void insertAtIndexInJobs(int index, String item) => jobs.insert(index, item);
  void updateJobsAtIndex(int index, Function(String) updateFn) =>
      jobs[index] = updateFn(jobs[index]);

  List<String> companies = [];
  void addToCompanies(String item) => companies.add(item);
  void removeFromCompanies(String item) => companies.remove(item);
  void removeAtIndexFromCompanies(int index) => companies.removeAt(index);
  void insertAtIndexInCompanies(int index, String item) =>
      companies.insert(index, item);
  void updateCompaniesAtIndex(int index, Function(String) updateFn) =>
      companies[index] = updateFn(companies[index]);

  List<String> dates = [];
  void addToDates(String item) => dates.add(item);
  void removeFromDates(String item) => dates.remove(item);
  void removeAtIndexFromDates(int index) => dates.removeAt(index);
  void insertAtIndexInDates(int index, String item) =>
      dates.insert(index, item);
  void updateDatesAtIndex(int index, Function(String) updateFn) =>
      dates[index] = updateFn(dates[index]);

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - API (Resume writer)] action in Button widget.
  ApiCallResponse? apiResultap0;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  ResumesRecord? resume;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<WorkhistoryRecord>? asd;

  /// Query cache managers for this widget.

  final _workhystoryManager = StreamRequestManager<List<WorkhistoryRecord>>();
  Stream<List<WorkhistoryRecord>> workhystory({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Stream<List<WorkhistoryRecord>> Function() requestFn,
  }) =>
      _workhystoryManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearWorkhystoryCache() => _workhystoryManager.clear();
  void clearWorkhystoryCacheKey(String? uniqueKey) =>
      _workhystoryManager.clearRequest(uniqueKey);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();

    /// Dispose query cache managers for this widget.

    clearWorkhystoryCache();
  }
}
