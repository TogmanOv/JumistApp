import '/flutter_flow/flutter_flow_util.dart';
import 'report_resume_optimised_widget.dart' show ReportResumeOptimisedWidget;
import 'package:flutter/material.dart';

class ReportResumeOptimisedModel
    extends FlutterFlowModel<ReportResumeOptimisedWidget> {
  ///  Local state fields for this page.

  bool tab1 = false;

  bool tab2 = false;

  bool tab3 = false;

  bool tab4 = false;

  bool tab5 = false;

  bool tab6 = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
