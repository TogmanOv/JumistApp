import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'sign_up_page2_resume_upload_widget.dart'
    show SignUpPage2ResumeUploadWidget;
import 'package:flutter/material.dart';

class SignUpPage2ResumeUploadModel
    extends FlutterFlowModel<SignUpPage2ResumeUploadWidget> {
  ///  Local state fields for this page.

  ResumesRecord? filePath;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
