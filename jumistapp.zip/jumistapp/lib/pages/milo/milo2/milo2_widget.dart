import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';
import 'milo2_model.dart';
export 'milo2_model.dart';

class Milo2Widget extends StatefulWidget {
  const Milo2Widget({
    super.key,
    required this.user,
  });

  final String? user;

  @override
  State<Milo2Widget> createState() => _Milo2WidgetState();
}

class _Milo2WidgetState extends State<Milo2Widget> {
  late Milo2Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Milo2Model());

    logFirebaseEvent('screen_view', parameters: {'screen_name': 'Milo2'});
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFFFFF7F2),
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Align(
                alignment: const AlignmentDirectional(0.0, 0.0),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(0.0),
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          width: double.infinity,
                          height: 100.0,
                          decoration: const BoxDecoration(
                            color: Colors.transparent,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: double.infinity,
                                decoration: const BoxDecoration(
                                  color: Colors.transparent,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment:
                                          const AlignmentDirectional(-1.0, 0.0),
                                      child: RichText(
                                        textScaler:
                                            MediaQuery.of(context).textScaler,
                                        text: TextSpan(
                                          children: [
                                            TextSpan(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'l8zuilan' /* Milo */,
                                              ),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .titleLarge
                                                      .override(
                                                        fontFamily: 'SF Pro',
                                                        letterSpacing: 0.0,
                                                        useGoogleFonts: false,
                                                      ),
                                            ),
                                            TextSpan(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'yfqv4jp5' /* 
Have a virtual interview
to p... */
                                                ,
                                              ),
                                              style: const TextStyle(),
                                            )
                                          ],
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'SF Pro',
                                                letterSpacing: 0.0,
                                                useGoogleFonts: false,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                height: 100.0,
                                decoration: const BoxDecoration(
                                  color: Colors.transparent,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    InkWell(
                                      splashColor: Colors.transparent,
                                      focusColor: Colors.transparent,
                                      hoverColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      onTap: () async {
                                        logFirebaseEvent(
                                            'MILO2_PAGE_CircleImage_eef379l3_ON_TAP');
                                        logFirebaseEvent(
                                            'CircleImage_navigate_to');

                                        context.pushNamed('Profile');
                                      },
                                      child: Container(
                                        width: 45.0,
                                        height: 45.0,
                                        clipBehavior: Clip.antiAlias,
                                        decoration: const BoxDecoration(
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.network(
                                          'https://picsum.photos/seed/235/600',
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ].divide(const SizedBox(height: 48.0)),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(0.0),
                  child: Image.asset(
                    'assets/images/Interview_Bot_(1).png',
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              Builder(
                builder: (context) {
                  if (_model.isRecording == false ? true : false) {
                    return Container(
                      width: 150.0,
                      height: 85.0,
                      decoration: const BoxDecoration(),
                      child: InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          logFirebaseEvent('MILO2_PAGE_Icon_hjgl9qgk_ON_TAP');
                          logFirebaseEvent('Icon_start_audio_recording');
                          await startAudioRecording(
                            context,
                            audioRecorder: _model.audioRecorder ??=
                                AudioRecorder(),
                          );

                          logFirebaseEvent('Icon_update_page_state');
                          setState(() {
                            _model.isRecording = !_model.isRecording;
                          });
                        },
                        child: Icon(
                          Icons.mic_sharp,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 90.0,
                        ),
                      ),
                    );
                  } else {
                    return Container(
                      width: 150.0,
                      height: 85.0,
                      decoration: const BoxDecoration(),
                      child: InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          logFirebaseEvent('MILO2_PAGE_Icon_r9fp5vr7_ON_TAP');
                          logFirebaseEvent('Icon_stop_audio_recording');
                          await stopAudioRecording(
                            audioRecorder: _model.audioRecorder,
                            audioName: 'recordedFileBytes.mp3',
                            onRecordingComplete: (audioFilePath, audioBytes) {
                              _model.audioPath = audioFilePath;
                              _model.recordedFileBytes = audioBytes;
                            },
                          );

                          logFirebaseEvent('Icon_update_page_state');
                          setState(() {
                            _model.isRecording = !_model.isRecording;
                          });
                          logFirebaseEvent('Icon_backend_call');
                          _model.apiResultd5e =
                              await IVBotGroup.transcribeCandidateCall.call(
                            userToken: FFAppState().usertoken,
                            file: _model.audioPath,
                          );
                          if ((_model.apiResultd5e?.succeeded ?? true)) {
                            logFirebaseEvent('Icon_backend_call');
                            _model.receiveBot =
                                await IVBotGroup.receiveBotCall.call(
                              token: FFAppState().usertoken,
                              voiceId: 't0jbNlBVZ17f02VDIeMI',
                            );
                            logFirebaseEvent('Icon_play_sound');
                            _model.soundPlayer ??= AudioPlayer();
                            if (_model.soundPlayer!.playing) {
                              await _model.soundPlayer!.stop();
                            }
                            _model.soundPlayer!.setVolume(1.0);
                            _model.soundPlayer!
                                .setUrl(getJsonField(
                                  (_model.receiveBot?.jsonBody ?? ''),
                                  r'''$.audio_url''',
                                ).toString())
                                .then((_) => _model.soundPlayer!.play());
                          }

                          setState(() {});
                        },
                        child: Icon(
                          Icons.stop_circle,
                          color: FlutterFlowTheme.of(context).primaryText,
                          size: 90.0,
                        ),
                      ),
                    );
                  }
                },
              ),
              Align(
                alignment: const AlignmentDirectional(0.0, 0.0),
                child: Container(
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    color: Colors.transparent,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Align(
                        alignment: const AlignmentDirectional(0.0, 0.0),
                        child: FFButtonWidget(
                          onPressed: () async {
                            logFirebaseEvent('MILO2_PAGE_LEAVE_BTN_ON_TAP');
                            logFirebaseEvent('Button_navigate_to');

                            context.pushNamed('Milo1');
                          },
                          text: FFLocalizations.of(context).getText(
                            '3r5ti387' /* Leave */,
                          ),
                          options: FFButtonOptions(
                            width: double.infinity,
                            height: 48.0,
                            padding: const EdgeInsets.all(0.0),
                            iconPadding: const EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: Colors.transparent,
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'SF Pro',
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.normal,
                                  useGoogleFonts: false,
                                ),
                            elevation: 0.0,
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).borderColor,
                              width: 0.5,
                            ),
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(height: 10.0)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
