import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'milo2_widget.dart' show Milo2Widget;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:record/record.dart';

class Milo2Model extends FlutterFlowModel<Milo2Widget> {
  ///  Local state fields for this page.

  bool isRecording = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  AudioRecorder? audioRecorder;
  String? audioPath;
  FFUploadedFile recordedFileBytes =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  // Stores action output result for [Backend Call - API (TranscribeCandidate)] action in Icon widget.
  ApiCallResponse? apiResultd5e;
  // Stores action output result for [Backend Call - API (ReceiveBot)] action in Icon widget.
  ApiCallResponse? receiveBot;
  AudioPlayer? soundPlayer;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
