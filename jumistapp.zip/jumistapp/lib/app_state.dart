import 'package:flutter/material.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<String> _jobs = [];
  List<String> get jobs => _jobs;
  set jobs(List<String> value) {
    _jobs = value;
  }

  void addToJobs(String value) {
    _jobs.add(value);
  }

  void removeFromJobs(String value) {
    _jobs.remove(value);
  }

  void removeAtIndexFromJobs(int index) {
    _jobs.removeAt(index);
  }

  void updateJobsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _jobs[index] = updateFn(_jobs[index]);
  }

  void insertAtIndexInJobs(int index, String value) {
    _jobs.insert(index, value);
  }

  List<String> _companies = [];
  List<String> get companies => _companies;
  set companies(List<String> value) {
    _companies = value;
  }

  void addToCompanies(String value) {
    _companies.add(value);
  }

  void removeFromCompanies(String value) {
    _companies.remove(value);
  }

  void removeAtIndexFromCompanies(int index) {
    _companies.removeAt(index);
  }

  void updateCompaniesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _companies[index] = updateFn(_companies[index]);
  }

  void insertAtIndexInCompanies(int index, String value) {
    _companies.insert(index, value);
  }

  List<String> _skills = [];
  List<String> get skills => _skills;
  set skills(List<String> value) {
    _skills = value;
  }

  void addToSkills(String value) {
    _skills.add(value);
  }

  void removeFromSkills(String value) {
    _skills.remove(value);
  }

  void removeAtIndexFromSkills(int index) {
    _skills.removeAt(index);
  }

  void updateSkillsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _skills[index] = updateFn(_skills[index]);
  }

  void insertAtIndexInSkills(int index, String value) {
    _skills.insert(index, value);
  }

  List<String> _dates = [];
  List<String> get dates => _dates;
  set dates(List<String> value) {
    _dates = value;
  }

  void addToDates(String value) {
    _dates.add(value);
  }

  void removeFromDates(String value) {
    _dates.remove(value);
  }

  void removeAtIndexFromDates(int index) {
    _dates.removeAt(index);
  }

  void updateDatesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _dates[index] = updateFn(_dates[index]);
  }

  void insertAtIndexInDates(int index, String value) {
    _dates.insert(index, value);
  }

  List<String> _industry = [];
  List<String> get industry => _industry;
  set industry(List<String> value) {
    _industry = value;
  }

  void addToIndustry(String value) {
    _industry.add(value);
  }

  void removeFromIndustry(String value) {
    _industry.remove(value);
  }

  void removeAtIndexFromIndustry(int index) {
    _industry.removeAt(index);
  }

  void updateIndustryAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _industry[index] = updateFn(_industry[index]);
  }

  void insertAtIndexInIndustry(int index, String value) {
    _industry.insert(index, value);
  }

  List<String> _language = [];
  List<String> get language => _language;
  set language(List<String> value) {
    _language = value;
  }

  void addToLanguage(String value) {
    _language.add(value);
  }

  void removeFromLanguage(String value) {
    _language.remove(value);
  }

  void removeAtIndexFromLanguage(int index) {
    _language.removeAt(index);
  }

  void updateLanguageAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _language[index] = updateFn(_language[index]);
  }

  void insertAtIndexInLanguage(int index, String value) {
    _language.insert(index, value);
  }

  List<String> _Subject = [];
  List<String> get Subject => _Subject;
  set Subject(List<String> value) {
    _Subject = value;
  }

  void addToSubject(String value) {
    _Subject.add(value);
  }

  void removeFromSubject(String value) {
    _Subject.remove(value);
  }

  void removeAtIndexFromSubject(int index) {
    _Subject.removeAt(index);
  }

  void updateSubjectAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _Subject[index] = updateFn(_Subject[index]);
  }

  void insertAtIndexInSubject(int index, String value) {
    _Subject.insert(index, value);
  }

  List<String> _job = [];
  List<String> get job => _job;
  set job(List<String> value) {
    _job = value;
  }

  void addToJob(String value) {
    _job.add(value);
  }

  void removeFromJob(String value) {
    _job.remove(value);
  }

  void removeAtIndexFromJob(int index) {
    _job.removeAt(index);
  }

  void updateJobAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _job[index] = updateFn(_job[index]);
  }

  void insertAtIndexInJob(int index, String value) {
    _job.insert(index, value);
  }

  List<String> _joblevel = [];
  List<String> get joblevel => _joblevel;
  set joblevel(List<String> value) {
    _joblevel = value;
  }

  void addToJoblevel(String value) {
    _joblevel.add(value);
  }

  void removeFromJoblevel(String value) {
    _joblevel.remove(value);
  }

  void removeAtIndexFromJoblevel(int index) {
    _joblevel.removeAt(index);
  }

  void updateJoblevelAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _joblevel[index] = updateFn(_joblevel[index]);
  }

  void insertAtIndexInJoblevel(int index, String value) {
    _joblevel.insert(index, value);
  }

  int _questions = 0;
  int get questions => _questions;
  set questions(int value) {
    _questions = value;
  }

  String _useraudio = '';
  String get useraudio => _useraudio;
  set useraudio(String value) {
    _useraudio = value;
  }

  String _email = '';
  String get email => _email;
  set email(String value) {
    _email = value;
  }

  String _password = '';
  String get password => _password;
  set password(String value) {
    _password = value;
  }

  String _usertoken = '';
  String get usertoken => _usertoken;
  set usertoken(String value) {
    _usertoken = value;
  }

  List<String> _startdate = [];
  List<String> get startdate => _startdate;
  set startdate(List<String> value) {
    _startdate = value;
  }

  void addToStartdate(String value) {
    _startdate.add(value);
  }

  void removeFromStartdate(String value) {
    _startdate.remove(value);
  }

  void removeAtIndexFromStartdate(int index) {
    _startdate.removeAt(index);
  }

  void updateStartdateAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _startdate[index] = updateFn(_startdate[index]);
  }

  void insertAtIndexInStartdate(int index, String value) {
    _startdate.insert(index, value);
  }

  List<String> _enddate = [];
  List<String> get enddate => _enddate;
  set enddate(List<String> value) {
    _enddate = value;
  }

  void addToEnddate(String value) {
    _enddate.add(value);
  }

  void removeFromEnddate(String value) {
    _enddate.remove(value);
  }

  void removeAtIndexFromEnddate(int index) {
    _enddate.removeAt(index);
  }

  void updateEnddateAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _enddate[index] = updateFn(_enddate[index]);
  }

  void insertAtIndexInEnddate(int index, String value) {
    _enddate.insert(index, value);
  }
}
