import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'choice_chips_model.dart';
export 'choice_chips_model.dart';

class ChoiceChipsWidget extends StatefulWidget {
  const ChoiceChipsWidget({
    super.key,
    required this.color,
    required this.text,
    this.index,
    required this.textColor,
  });

  final Color? color;
  final String? text;
  final int? index;
  final Color? textColor;

  @override
  State<ChoiceChipsWidget> createState() => _ChoiceChipsWidgetState();
}

class _ChoiceChipsWidgetState extends State<ChoiceChipsWidget> {
  late ChoiceChipsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ChoiceChipsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40.0,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF173235),
            Color(0xFF106967),
            Color(0xFF4FBC9B),
            Color(0xFF32BFD9),
            Color(0xFFEFCA7D)
          ],
          stops: [0.0, 0.0, 0.0, 0.5, 1.0],
          begin: AlignmentDirectional(0.0, -1.0),
          end: AlignmentDirectional(0, 1.0),
        ),
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Align(
        alignment: const AlignmentDirectional(0.0, 0.0),
        child: Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(12.0, 6.0, 12.0, 6.0),
          child: Text(
            widget.text!,
            textAlign: TextAlign.center,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'SF Pro',
                  color: widget.textColor,
                  letterSpacing: 0.0,
                  useGoogleFonts: false,
                ),
          ),
        ),
      ),
    );
  }
}
