import '/flutter_flow/flutter_flow_util.dart';
import 'choice_chips_widget.dart' show ChoiceChipsWidget;
import 'package:flutter/material.dart';

class ChoiceChipsModel extends FlutterFlowModel<ChoiceChipsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
