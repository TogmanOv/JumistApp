import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'loadingbtmsheet_model.dart';
export 'loadingbtmsheet_model.dart';

class LoadingbtmsheetWidget extends StatefulWidget {
  const LoadingbtmsheetWidget({super.key});

  @override
  State<LoadingbtmsheetWidget> createState() => _LoadingbtmsheetWidgetState();
}

class _LoadingbtmsheetWidgetState extends State<LoadingbtmsheetWidget> {
  late LoadingbtmsheetModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LoadingbtmsheetModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xFF173235),
            Color(0xFF106967),
            Color(0xFF4FBC9B),
            Color(0xFF32BFD9),
            Color(0xFFEFCA7D)
          ],
          stops: [0.0, 0.0, 0.0, 0.5, 1.0],
          begin: AlignmentDirectional(0.0, -1.0),
          end: AlignmentDirectional(0, 1.0),
        ),
      ),
    );
  }
}
