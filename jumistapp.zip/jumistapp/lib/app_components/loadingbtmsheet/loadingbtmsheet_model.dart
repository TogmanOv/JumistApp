import '/flutter_flow/flutter_flow_util.dart';
import 'loadingbtmsheet_widget.dart' show LoadingbtmsheetWidget;
import 'package:flutter/material.dart';

class LoadingbtmsheetModel extends FlutterFlowModel<LoadingbtmsheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
