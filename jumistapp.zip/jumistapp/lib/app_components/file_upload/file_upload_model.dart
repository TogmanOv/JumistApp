import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'file_upload_widget.dart' show FileUploadWidget;
import 'package:flutter/material.dart';

class FileUploadModel extends FlutterFlowModel<FileUploadWidget> {
  ///  Local state fields for this component.

  String? text = 'null';

  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // Stores action output result for [Backend Call - API (pdf)] action in Button widget.
  ApiCallResponse? apiResults6k;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
