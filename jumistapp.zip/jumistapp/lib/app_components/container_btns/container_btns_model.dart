import '/flutter_flow/flutter_flow_util.dart';
import 'container_btns_widget.dart' show ContainerBtnsWidget;
import 'package:flutter/material.dart';

class ContainerBtnsModel extends FlutterFlowModel<ContainerBtnsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
