import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class JobResultRecord extends FirestoreRecord {
  JobResultRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "job_title" field.
  String? _jobTitle;
  String get jobTitle => _jobTitle ?? '';
  bool hasJobTitle() => _jobTitle != null;

  // "date_created" field.
  DateTime? _dateCreated;
  DateTime? get dateCreated => _dateCreated;
  bool hasDateCreated() => _dateCreated != null;

  // "created_by" field.
  DocumentReference? _createdBy;
  DocumentReference? get createdBy => _createdBy;
  bool hasCreatedBy() => _createdBy != null;

  // "pdfFile" field.
  String? _pdfFile;
  String get pdfFile => _pdfFile ?? '';
  bool hasPdfFile() => _pdfFile != null;

  void _initializeFields() {
    _jobTitle = snapshotData['job_title'] as String?;
    _dateCreated = snapshotData['date_created'] as DateTime?;
    _createdBy = snapshotData['created_by'] as DocumentReference?;
    _pdfFile = snapshotData['pdfFile'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('job_result');

  static Stream<JobResultRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => JobResultRecord.fromSnapshot(s));

  static Future<JobResultRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => JobResultRecord.fromSnapshot(s));

  static JobResultRecord fromSnapshot(DocumentSnapshot snapshot) =>
      JobResultRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JobResultRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JobResultRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JobResultRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JobResultRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJobResultRecordData({
  String? jobTitle,
  DateTime? dateCreated,
  DocumentReference? createdBy,
  String? pdfFile,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'job_title': jobTitle,
      'date_created': dateCreated,
      'created_by': createdBy,
      'pdfFile': pdfFile,
    }.withoutNulls,
  );

  return firestoreData;
}

class JobResultRecordDocumentEquality implements Equality<JobResultRecord> {
  const JobResultRecordDocumentEquality();

  @override
  bool equals(JobResultRecord? e1, JobResultRecord? e2) {
    return e1?.jobTitle == e2?.jobTitle &&
        e1?.dateCreated == e2?.dateCreated &&
        e1?.createdBy == e2?.createdBy &&
        e1?.pdfFile == e2?.pdfFile;
  }

  @override
  int hash(JobResultRecord? e) => const ListEquality()
      .hash([e?.jobTitle, e?.dateCreated, e?.createdBy, e?.pdfFile]);

  @override
  bool isValidKey(Object? o) => o is JobResultRecord;
}
