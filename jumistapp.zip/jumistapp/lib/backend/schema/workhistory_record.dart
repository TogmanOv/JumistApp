import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class WorkhistoryRecord extends FirestoreRecord {
  WorkhistoryRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "jobname" field.
  String? _jobname;
  String get jobname => _jobname ?? '';
  bool hasJobname() => _jobname != null;

  // "dateFrom" field.
  DateTime? _dateFrom;
  DateTime? get dateFrom => _dateFrom;
  bool hasDateFrom() => _dateFrom != null;

  // "dateTo" field.
  DateTime? _dateTo;
  DateTime? get dateTo => _dateTo;
  bool hasDateTo() => _dateTo != null;

  // "skills" field.
  String? _skills;
  String get skills => _skills ?? '';
  bool hasSkills() => _skills != null;

  // "company" field.
  String? _company;
  String get company => _company ?? '';
  bool hasCompany() => _company != null;

  // "dates" field.
  String? _dates;
  String get dates => _dates ?? '';
  bool hasDates() => _dates != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _jobname = snapshotData['jobname'] as String?;
    _dateFrom = snapshotData['dateFrom'] as DateTime?;
    _dateTo = snapshotData['dateTo'] as DateTime?;
    _skills = snapshotData['skills'] as String?;
    _company = snapshotData['company'] as String?;
    _dates = snapshotData['dates'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('workhistory')
          : FirebaseFirestore.instance.collectionGroup('workhistory');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('workhistory').doc(id);

  static Stream<WorkhistoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WorkhistoryRecord.fromSnapshot(s));

  static Future<WorkhistoryRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WorkhistoryRecord.fromSnapshot(s));

  static WorkhistoryRecord fromSnapshot(DocumentSnapshot snapshot) =>
      WorkhistoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WorkhistoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WorkhistoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WorkhistoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WorkhistoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWorkhistoryRecordData({
  String? jobname,
  DateTime? dateFrom,
  DateTime? dateTo,
  String? skills,
  String? company,
  String? dates,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'jobname': jobname,
      'dateFrom': dateFrom,
      'dateTo': dateTo,
      'skills': skills,
      'company': company,
      'dates': dates,
    }.withoutNulls,
  );

  return firestoreData;
}

class WorkhistoryRecordDocumentEquality implements Equality<WorkhistoryRecord> {
  const WorkhistoryRecordDocumentEquality();

  @override
  bool equals(WorkhistoryRecord? e1, WorkhistoryRecord? e2) {
    return e1?.jobname == e2?.jobname &&
        e1?.dateFrom == e2?.dateFrom &&
        e1?.dateTo == e2?.dateTo &&
        e1?.skills == e2?.skills &&
        e1?.company == e2?.company &&
        e1?.dates == e2?.dates;
  }

  @override
  int hash(WorkhistoryRecord? e) => const ListEquality().hash(
      [e?.jobname, e?.dateFrom, e?.dateTo, e?.skills, e?.company, e?.dates]);

  @override
  bool isValidKey(Object? o) => o is WorkhistoryRecord;
}
