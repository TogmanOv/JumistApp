import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class EnhanceRecord extends FirestoreRecord {
  EnhanceRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "pdfLink" field.
  String? _pdfLink;
  String get pdfLink => _pdfLink ?? '';
  bool hasPdfLink() => _pdfLink != null;

  // "crated_date" field.
  DateTime? _cratedDate;
  DateTime? get cratedDate => _cratedDate;
  bool hasCratedDate() => _cratedDate != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _pdfLink = snapshotData['pdfLink'] as String?;
    _cratedDate = snapshotData['crated_date'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('enhance')
          : FirebaseFirestore.instance.collectionGroup('enhance');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('enhance').doc(id);

  static Stream<EnhanceRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EnhanceRecord.fromSnapshot(s));

  static Future<EnhanceRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EnhanceRecord.fromSnapshot(s));

  static EnhanceRecord fromSnapshot(DocumentSnapshot snapshot) =>
      EnhanceRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EnhanceRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EnhanceRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EnhanceRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EnhanceRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEnhanceRecordData({
  String? pdfLink,
  DateTime? cratedDate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'pdfLink': pdfLink,
      'crated_date': cratedDate,
    }.withoutNulls,
  );

  return firestoreData;
}

class EnhanceRecordDocumentEquality implements Equality<EnhanceRecord> {
  const EnhanceRecordDocumentEquality();

  @override
  bool equals(EnhanceRecord? e1, EnhanceRecord? e2) {
    return e1?.pdfLink == e2?.pdfLink && e1?.cratedDate == e2?.cratedDate;
  }

  @override
  int hash(EnhanceRecord? e) =>
      const ListEquality().hash([e?.pdfLink, e?.cratedDate]);

  @override
  bool isValidKey(Object? o) => o is EnhanceRecord;
}
