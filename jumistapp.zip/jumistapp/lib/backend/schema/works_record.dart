import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class WorksRecord extends FirestoreRecord {
  WorksRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "jobname" field.
  List<String>? _jobname;
  List<String> get jobname => _jobname ?? const [];
  bool hasJobname() => _jobname != null;

  // "dateFrom" field.
  List<DateTime>? _dateFrom;
  List<DateTime> get dateFrom => _dateFrom ?? const [];
  bool hasDateFrom() => _dateFrom != null;

  // "dateTo" field.
  List<DateTime>? _dateTo;
  List<DateTime> get dateTo => _dateTo ?? const [];
  bool hasDateTo() => _dateTo != null;

  // "skills" field.
  List<String>? _skills;
  List<String> get skills => _skills ?? const [];
  bool hasSkills() => _skills != null;

  // "company" field.
  List<String>? _company;
  List<String> get company => _company ?? const [];
  bool hasCompany() => _company != null;

  // "dates" field.
  List<String>? _dates;
  List<String> get dates => _dates ?? const [];
  bool hasDates() => _dates != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _jobname = getDataList(snapshotData['jobname']);
    _dateFrom = getDataList(snapshotData['dateFrom']);
    _dateTo = getDataList(snapshotData['dateTo']);
    _skills = getDataList(snapshotData['skills']);
    _company = getDataList(snapshotData['company']);
    _dates = getDataList(snapshotData['dates']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('works')
          : FirebaseFirestore.instance.collectionGroup('works');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('works').doc(id);

  static Stream<WorksRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WorksRecord.fromSnapshot(s));

  static Future<WorksRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WorksRecord.fromSnapshot(s));

  static WorksRecord fromSnapshot(DocumentSnapshot snapshot) => WorksRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WorksRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WorksRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WorksRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WorksRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWorksRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class WorksRecordDocumentEquality implements Equality<WorksRecord> {
  const WorksRecordDocumentEquality();

  @override
  bool equals(WorksRecord? e1, WorksRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.jobname, e2?.jobname) &&
        listEquality.equals(e1?.dateFrom, e2?.dateFrom) &&
        listEquality.equals(e1?.dateTo, e2?.dateTo) &&
        listEquality.equals(e1?.skills, e2?.skills) &&
        listEquality.equals(e1?.company, e2?.company) &&
        listEquality.equals(e1?.dates, e2?.dates);
  }

  @override
  int hash(WorksRecord? e) => const ListEquality().hash(
      [e?.jobname, e?.dateFrom, e?.dateTo, e?.skills, e?.company, e?.dates]);

  @override
  bool isValidKey(Object? o) => o is WorksRecord;
}
