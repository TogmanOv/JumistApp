import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class ResultsRecord extends FirestoreRecord {
  ResultsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "coach_type" field.
  String? _coachType;
  String get coachType => _coachType ?? '';
  bool hasCoachType() => _coachType != null;

  // "result" field.
  String? _result;
  String get result => _result ?? '';
  bool hasResult() => _result != null;

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _coachType = snapshotData['coach_type'] as String?;
    _result = snapshotData['result'] as String?;
    _date = snapshotData['date'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('results')
          : FirebaseFirestore.instance.collectionGroup('results');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('results').doc(id);

  static Stream<ResultsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ResultsRecord.fromSnapshot(s));

  static Future<ResultsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ResultsRecord.fromSnapshot(s));

  static ResultsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ResultsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ResultsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ResultsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ResultsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ResultsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createResultsRecordData({
  String? coachType,
  String? result,
  DateTime? date,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'coach_type': coachType,
      'result': result,
      'date': date,
    }.withoutNulls,
  );

  return firestoreData;
}

class ResultsRecordDocumentEquality implements Equality<ResultsRecord> {
  const ResultsRecordDocumentEquality();

  @override
  bool equals(ResultsRecord? e1, ResultsRecord? e2) {
    return e1?.coachType == e2?.coachType &&
        e1?.result == e2?.result &&
        e1?.date == e2?.date;
  }

  @override
  int hash(ResultsRecord? e) =>
      const ListEquality().hash([e?.coachType, e?.result, e?.date]);

  @override
  bool isValidKey(Object? o) => o is ResultsRecord;
}
