import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class ResumesRecord extends FirestoreRecord {
  ResumesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "resume" field.
  String? _resume;
  String get resume => _resume ?? '';
  bool hasResume() => _resume != null;

  // "date_created" field.
  DateTime? _dateCreated;
  DateTime? get dateCreated => _dateCreated;
  bool hasDateCreated() => _dateCreated != null;

  // "pdfFile" field.
  String? _pdfFile;
  String get pdfFile => _pdfFile ?? '';
  bool hasPdfFile() => _pdfFile != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _resume = snapshotData['resume'] as String?;
    _dateCreated = snapshotData['date_created'] as DateTime?;
    _pdfFile = snapshotData['pdfFile'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('resumes')
          : FirebaseFirestore.instance.collectionGroup('resumes');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('resumes').doc(id);

  static Stream<ResumesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ResumesRecord.fromSnapshot(s));

  static Future<ResumesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ResumesRecord.fromSnapshot(s));

  static ResumesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ResumesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ResumesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ResumesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ResumesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ResumesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createResumesRecordData({
  String? title,
  String? resume,
  DateTime? dateCreated,
  String? pdfFile,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'resume': resume,
      'date_created': dateCreated,
      'pdfFile': pdfFile,
    }.withoutNulls,
  );

  return firestoreData;
}

class ResumesRecordDocumentEquality implements Equality<ResumesRecord> {
  const ResumesRecordDocumentEquality();

  @override
  bool equals(ResumesRecord? e1, ResumesRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.resume == e2?.resume &&
        e1?.dateCreated == e2?.dateCreated &&
        e1?.pdfFile == e2?.pdfFile;
  }

  @override
  int hash(ResumesRecord? e) => const ListEquality()
      .hash([e?.title, e?.resume, e?.dateCreated, e?.pdfFile]);

  @override
  bool isValidKey(Object? o) => o is ResumesRecord;
}
