import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyC2Frq1iTDaTIPLe5CH_oLm1P0uuAgjSXY",
            authDomain: "diplom-i6gagl.firebaseapp.com",
            projectId: "diplom-i6gagl",
            storageBucket: "diplom-i6gagl.appspot.com",
            messagingSenderId: "737524403706",
            appId: "1:737524403706:web:f858bfc1cb13c31d9ca843"));
  } else {
    await Firebase.initializeApp();
  }
}
