import 'dart:convert';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start OpenAi GPT Group Code

class OpenAiGPTGroup {
  static String getBaseUrl() => 'https://api.openai.com/v1';
  static Map<String, String> headers = {
    'Content-Type': 'application/json',
    'Authorization':
        'Bearer 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',
  };
  static CareerCoachCall careerCoachCall = CareerCoachCall();
  static PerfectCandidateInterviewingCall perfectCandidateInterviewingCall =
      PerfectCandidateInterviewingCall();
  static ResumeWriterCall resumeWriterCall = ResumeWriterCall();
  static RecommendMeJobsCall recommendMeJobsCall = RecommendMeJobsCall();
  static AnalyzeResumeCall analyzeResumeCall = AnalyzeResumeCall();
  static RoleExpectationsCall roleExpectationsCall = RoleExpectationsCall();
  static RoleSummaryCall roleSummaryCall = RoleSummaryCall();
  static CandidateAssessmentCall candidateAssessmentCall =
      CandidateAssessmentCall();
  static InterviewQsCall interviewQsCall = InterviewQsCall();
  static OutreachMessagesCall outreachMessagesCall = OutreachMessagesCall();
  static CoverLetterCall coverLetterCall = CoverLetterCall();
  static BooleanSearchStringCall booleanSearchStringCall =
      BooleanSearchStringCall();
  static RelevantJobsCall relevantJobsCall = RelevantJobsCall();
  static CompensationAnalysisCall compensationAnalysisCall =
      CompensationAnalysisCall();
  static FindJobsCall findJobsCall = FindJobsCall();
}

class CareerCoachCall {
  Future<ApiCallResponse> call({
    String? jobDescription = '',
    String? resume = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a Career Coach."
    },
    {
      "role": "user",
      "content": "Given the job description below, analyze the key skills and qualifications mentioned and provide recommendations on how to optimize the resume provided below to increase my chances of my resume being selected for an interview. Provide guidance on how to highlight relevant skills and experience in my resume aligned with the job description. Provide guidance on how to tailor the verbiage and formatting of the resume to align with the job description. Provide guidance on how to effectively showcase achievements and accomplishments from my resume. Offer suggestions for additional training, certifications, or experience that would enhance the my qualifications for the role. Provide any possible metrics to include on the resume. Job description: $jobDescription. Resume:$resume."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Career Coach',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  int? createdTimeStamp(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.created''',
      ));
  String? content(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
  String? role(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.role''',
      ));
}

class PerfectCandidateInterviewingCall {
  Future<ApiCallResponse> call({
    String? jobDescription = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a perfect candidate interviewing for a role."
    },
    {
      "role": "user",
      "content": "Using the job description below as a reference, identify gaps or things that make you curious and provide a total of five fully developed questions a candidate would ask an interviewer about the role. Job Description: $jobDescription"
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Perfect candidate interviewing',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  dynamic createdTime(dynamic response) => getJsonField(
        response,
        r'''$.created''',
      );
  dynamic role(dynamic response) => getJsonField(
        response,
        r'''$.choices[:].message.role''',
      );
  dynamic content(dynamic response) => getJsonField(
        response,
        r'''$.choices[:].message.content''',
      );
}

class ResumeWriterCall {
  Future<ApiCallResponse> call({
    String? skills = '',
    String? dates = '',
    String? jobs = '',
    String? company = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a professional resume writer and will be writing a beautiful resume."
    },
    {
      "role": "user",
      "content": "At the end of my instruction I will be providing a set of criteria to build a resume which should include a professional summary. Each set is separated by a period. It will start with the Company name and dates, followed by the job title, and the set will end with skills acquired and used during my time. I will be giving you up to five sets. Use only the information in each set for that specific experience. You are going to create a resume in reverse chronological order. Using the skills provided for each job create summaries and bullets for each set of criteria. Criteria: $company $dates $jobs $skills.  $company $dates $jobs $skills. $company $dates $jobs $skills. $company $dates $jobs $skills. $company $dates $jobs $skills."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Resume writer',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  String? text(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

class RecommendMeJobsCall {
  Future<ApiCallResponse> call({
    String? resume = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are Professional Career Coach."
    },
    {
      "role": "user",
      "content": "Analyze my $resume and recommend jobs I could be successful in. Provide at least ten and one at least one sentence describing why you would recommend that job."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Recommend me jobs',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class AnalyzeResumeCall {
  Future<ApiCallResponse> call({
    String? resume = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are an expert career coach."
    },
    {
      "role": "user",
      "content": "I will give you a resume at the end of my instruction. Instruction: Analyze and critique the professional experience. Be very critical. Provide a list of actionable tips to improve the professional experience with specific examples you find within the resume. Using the same professional experience, provide recommended metrics to include. Provide a list of possible jobs that would be considered advancements in a career trajectory. Assuming I do not want to stay on that career trajectory, provide other jobs that the skills I possess would be successful in. Label each section as the following: Resume Tips, Potential Metrics, Career Trajectory, Other Jobs You’d Be Good At. Rewrite the resume incorporating the list of actionable tips you provided earlier. Do not provide tips focused on aesthetics or any redundant tips based on the resume provided. Do not mention an introductory summary in any of the tips. End of instruction. Resume is: $resume."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Analyze resume',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  int? createdTime(dynamic response) => castToType<int>(getJsonField(
        response,
        r'''$.created''',
      ));
  String? role(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.role''',
      ));
  String? content(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

class RoleExpectationsCall {
  Future<ApiCallResponse> call({
    String? jobDescription = '',
    String? jobTitle = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are manager of a $jobTitle."
    },
    {
      "role": "user",
      "content": "Analyze this job description: $jobDescription. Provide a timeline of expectations from the job description. Break the timeline in to three sections; 30-day, 60-day, and 90-day."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Role expectations',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  dynamic content(dynamic response) => getJsonField(
        response,
        r'''$.choices[:].message.content''',
      );
}

class RoleSummaryCall {
  Future<ApiCallResponse> call({
    String? jobDescription = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a Career Coach."
    },
    {
      "role": "user",
      "content": "Analyze this job description: $jobDescription. Provide a one paragraph summary of expectations from the job description."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Role summary ',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class CandidateAssessmentCall {
  Future<ApiCallResponse> call({
    String? jobTitle = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a manager hiring for a $jobTitle"
    },
    {
      "role": "user",
      "content": "Create a pre-employment assessment to test practical knowledge for a $jobTitle to take before getting hired. Do not provide an introductory statement. Provide the answers to the questions on the assessment."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Candidate assessment ',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class InterviewQsCall {
  Future<ApiCallResponse> call({
    String? jobDescription = '',
    String? resume = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a career coach."
    },
    {
      "role": "user",
      "content": "I am going to send you a job description and my resume. Here is the job: $jobDescription. Here is my resume: $resume. Produce 10 interview questions based on the Job description and the answers to those questions based on my resume."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Interview Qs',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class OutreachMessagesCall {
  Future<ApiCallResponse> call({
    String? jobDescription = '',
    String? resume = '',
    String? jobTitle = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "The AI is to draft two personalized outreach emails using the exact skills and experiences from the user's resume that directly correspond to the job description provided. The AI should not make assumptions or create connections that are not explicitly stated in the resume or the job description. The first email is to be addressed to a specific hiring manager, the second is a general inquiry. Both should be professional, concise, and reflect only the user's actual qualifications."
    },
    {
      "role": "user",
      "content": "Here's the job description I'm interested in: $jobDescription. And here are the details from my resume: $resume. Please draft a personable, introductory email to the prospective hiring manager for the job, only highlighting the skills and experiences from my resume that align with the job requirements. Additionally, draft a second general inquiry email that can be addressed 'To Whom It May Concern,' which introduces me based on my resume and expresses an interest in the company."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Outreach messages',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class CoverLetterCall {
  Future<ApiCallResponse> call({
    String? jobTitle = '',
    String? jobDescription = '',
    String? resume = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "The AI is tasked with creating a cover letter based solely on the provided resume and job description. The AI should cross-reference qualifications and experiences mentioned in the resume with the requirements and responsibilities listed in the job description. It must not fabricate details or include any information that is not explicitly stated in the provided documents. The resulting cover letter should accurately reflect the candidate's background and how it relates to the job."
    },
    {
      "role": "user",
      "content": "Create a cover letter for the position of $jobTitle, using the information from the provided resume and the job description. Ensure that the cover letter highlights relevant experiences and qualifications from the resume that meet the job's requirements. Avoid adding any details not found in the resume or job description. Keep the cover letter professional, enthusiastic, and tailored to the role and company. Job Description: $jobDescription. Resume: $resume."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Cover Letter',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class BooleanSearchStringCall {
  Future<ApiCallResponse> call({
    String? resume = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a search engine that only speaks in google operators and only searches for job titles."
    },
    {
      "role": "user",
      "content": "At the end of my instruction I am going to give you a resume. With this resume you are only going to create one string of text used for searching, so please do not include anything but the string. With the contents of the resume I give you as inspiration, create a concatenated list of five job titles that someone with the skills you identify in the resume would be successful in. The job titles provided should be commonly used job titles. Use an OR operator to separate each job title and keep each job title in quotations. Resume: $resume"
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Boolean search string',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  String? content(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

class RelevantJobsCall {
  Future<ApiCallResponse> call({
    String? resume = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a Career Coach."
    },
    {
      "role": "user",
      "content": "At the end of my instruction I will give you a resume and I want you to provide a list of similar job titles that would have similar skills and responsibilities in a bulleted list. Resume: $resume."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'relevant jobs',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class CompensationAnalysisCall {
  Future<ApiCallResponse> call({
    String? jobTitle = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a compensation analyst with data up to June 2021."
    },
    {
      "role": "user",
      "content": "Please provide the average salary range for a $jobTitle. Include hourly rates. Do not mention you are an AI model. Statistical responses only, no conversational pleasantries. Cite your sources. Don't mention any dates."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Compensation Analysis',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  String? contet(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

class FindJobsCall {
  Future<ApiCallResponse> call({
    String? abilities = '',
  }) async {
    final baseUrl = OpenAiGPTGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo-16k",
  "messages": [
    {
      "role": "system",
      "content": "You are a search engine that only speaks in google operators and only searches for job titles."
    },
    {
      "role": "user",
      "content": "I am going to give a list of skills that explain the experience of a jobseeker. With the skills, create a concatenated list of five job titles that someone with those skills would be successful in. Use an OR operator to separate the job titles and keep each job title in quotations. Skills: $abilities."
    }
  ]
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Find Jobs',
      apiUrl: '$baseUrl/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  String? content(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.choices[:].message.content''',
      ));
}

/// End OpenAi GPT Group Code

/// Start IVBot Group Code

class IVBotGroup {
  static String getBaseUrl() =>
      'https://interview-bot-py-run-uuzwn5a7ca-uc.a.run.app';
  static Map<String, String> headers = {};
  static ContextCall contextCall = ContextCall();
  static ReceiveBotCall receiveBotCall = ReceiveBotCall();
  static TranscribeCandidateCall transcribeCandidateCall =
      TranscribeCandidateCall();
  static IVHistoryCall iVHistoryCall = IVHistoryCall();
}

class ContextCall {
  Future<ApiCallResponse> call({
    String? destTranslateLang = '',
    String? industry = '',
    String? jobLevel = '',
    int? numInterviewQuestions,
    String? subject = '',
    String? token = '',
  }) async {
    final baseUrl = IVBotGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "dest_translate_lang": "$destTranslateLang",
  "industry": "$industry",
  "job_level": "$jobLevel",
  "num_interview_questions": "$numInterviewQuestions",
  "subject": "$subject",
  "token": "$token"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Context',
      apiUrl: '$baseUrl/reset-chat-and-set-chat-context',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: true,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class ReceiveBotCall {
  Future<ApiCallResponse> call({
    String? token = '',
    String? voiceId = '',
  }) async {
    final baseUrl = IVBotGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "token": "$token",
  "voice_id": "t0jbNlBVZ17f02VDIeMI"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'ReceiveBot',
      apiUrl: '$baseUrl/receive-bot-message',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class TranscribeCandidateCall {
  Future<ApiCallResponse> call({
    String? userToken = '',
    String? file = '',
  }) async {
    final baseUrl = IVBotGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "User_token": "$userToken",
  "file": "$file"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'TranscribeCandidate',
      apiUrl: '$baseUrl/transcribe-user-audio/',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class IVHistoryCall {
  Future<ApiCallResponse> call({
    String? usertoken = '',
  }) async {
    final baseUrl = IVBotGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "token": "$usertoken"
}
''';
    return ApiManager.instance.makeApiCall(
      callName: 'IVHistory',
      apiUrl: '$baseUrl/return-chat-history',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

/// End IVBot Group Code

class PdfCall {
  static Future<ApiCallResponse> call({
    String? pdfUrl = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'pdf',
      apiUrl: 'https://yetxxcard.pythonanywhere.com/get_pdf_text',
      callType: ApiCallType.GET,
      headers: {
        'Content-Type': 'application/json',
      },
      params: {
        'pdf_url': pdfUrl,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? text(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.pdf_text''',
      ));
  static dynamic error(dynamic response) => getJsonField(
        response,
        r'''$.error''',
      );
}

class DocCall {
  static Future<ApiCallResponse> call({
    String? docxUrl = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'doc',
      apiUrl: 'https://yetxxcard.pythonanywhere.com/get_word_text',
      callType: ApiCallType.GET,
      headers: {
        'Content-Type': 'application/json',
      },
      params: {
        'docx_url': docxUrl,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic docTxt(dynamic response) => getJsonField(
        response,
        r'''$.word_text''',
      );
}

class JobDescrCall {
  static Future<ApiCallResponse> call({
    String? url = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'JobDescr',
      apiUrl: 'https://scraper-api-vplcwtayza-wl.a.run.app/v1/scrape',
      callType: ApiCallType.GET,
      headers: {
        'x-hiapply-api-key': '18iGLRWrefM14S8KpHfJlXUEpPa8I1PKqwVHxE3WCQS0pkRL',
        'Content-Type': 'application/json',
      },
      params: {
        'url': url,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }

  static String? title(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.title''',
      ));
  static String? content(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.textContent''',
      ));
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
