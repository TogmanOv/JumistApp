import '/flutter_flow/flutter_flow_util.dart';
import 'empty_widget.dart' show EmptyWidget;
import 'package:flutter/material.dart';

class EmptyModel extends FlutterFlowModel<EmptyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
