import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'custom_buttons_model.dart';
export 'custom_buttons_model.dart';

class CustomButtonsWidget extends StatefulWidget {
  const CustomButtonsWidget({super.key});

  @override
  State<CustomButtonsWidget> createState() => _CustomButtonsWidgetState();
}

class _CustomButtonsWidgetState extends State<CustomButtonsWidget> {
  late CustomButtonsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CustomButtonsModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('CUSTOM_BUTTONS_CustomButtons_ON_INIT_STA');
      logFirebaseEvent('CustomButtons_update_component_state');
      setState(() {
        _model.buttonclicked = true;
      });
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            logFirebaseEvent('CUSTOM_BUTTONS_Column_dkxfois7_ON_TAP');
            logFirebaseEvent('Column_update_component_state');
            setState(() {
              _model.buttonclicked = !_model.buttonclicked;
            });
          },
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.transparent,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    FFButtonWidget(
                      onPressed: () async {
                        logFirebaseEvent(
                            'CUSTOM_BUTTONS_WRITTEN_RESUME_BTN_ON_TAP');
                        logFirebaseEvent('Button_update_component_state');
                        setState(() {
                          _model.buttonclicked = !_model.buttonclicked;
                        });
                      },
                      text: FFLocalizations.of(context).getText(
                        'ic7s0w6z' /* Written Resume */,
                      ),
                      options: FFButtonOptions(
                        width: 150.0,
                        height: 48.0,
                        padding: const EdgeInsets.all(2.0),
                        iconPadding:
                            const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: valueOrDefault<Color>(
                          _model.buttonclicked == false
                              ? FlutterFlowTheme.of(context).accent4
                              : FlutterFlowTheme.of(context).primaryBackground,
                          FlutterFlowTheme.of(context).accent4,
                        ),
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'SF Pro',
                                  color: _model.buttonclicked == false
                                      ? FlutterFlowTheme.of(context).accent4
                                      : FlutterFlowTheme.of(context)
                                          .primaryBackground,
                                  fontSize: 14.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.normal,
                                  useGoogleFonts: false,
                                ),
                        elevation: 0.0,
                        borderSide: const BorderSide(
                          color: Colors.transparent,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ],
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
