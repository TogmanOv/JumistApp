import '/flutter_flow/flutter_flow_util.dart';
import 'custom_buttons_widget.dart' show CustomButtonsWidget;
import 'package:flutter/material.dart';

class CustomButtonsModel extends FlutterFlowModel<CustomButtonsWidget> {
  ///  Local state fields for this component.

  bool buttonclicked = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
