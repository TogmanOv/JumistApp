import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'radiobutton_model.dart';
export 'radiobutton_model.dart';

class RadiobuttonWidget extends StatefulWidget {
  const RadiobuttonWidget({super.key});

  @override
  State<RadiobuttonWidget> createState() => _RadiobuttonWidgetState();
}

class _RadiobuttonWidgetState extends State<RadiobuttonWidget> {
  late RadiobuttonModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => RadiobuttonModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ResumesRecord>>(
      stream: queryResumesRecord(),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return const Center(
            child: SizedBox(
              width: 50.0,
              height: 50.0,
              child: SpinKitChasingDots(
                color: Color(0xFF173235),
                size: 50.0,
              ),
            ),
          );
        }
        List<ResumesRecord> radioButtonResumesRecordList = snapshot.data!;
        return FlutterFlowRadioButton(
          options: radioButtonResumesRecordList
              .map((e) => e.title)
              .toList()
              .toList(),
          onChanged: (val) => setState(() {}),
          controller: _model.radioButtonValueController ??=
              FormFieldController<String>(null),
          optionHeight: 45.0,
          optionWidth: MediaQuery.sizeOf(context).width * 1.0,
          textStyle: FlutterFlowTheme.of(context).labelMedium.override(
                fontFamily: 'SF Pro',
                letterSpacing: 0.0,
                useGoogleFonts: false,
              ),
          selectedTextStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'SF Pro',
                letterSpacing: 0.0,
                useGoogleFonts: false,
              ),
          buttonPosition: RadioButtonPosition.left,
          direction: Axis.vertical,
          radioButtonColor: FlutterFlowTheme.of(context).primary,
          inactiveRadioButtonColor: FlutterFlowTheme.of(context).secondaryText,
          toggleable: false,
          horizontalAlignment: WrapAlignment.start,
          verticalAlignment: WrapCrossAlignment.start,
        );
      },
    );
  }
}
