// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<DateTime> monthYearPicker(BuildContext context) async {
  DateTime? pickedDate;
  int? selectedYear;
  int? selectedMonth;
  final int currentYear = DateTime.now().year;
  final List<int> yearList = List.generate(21, (index) => currentYear - index);
  selectedYear = currentYear; // Default to current year

  // Show custom dialog
  pickedDate = await showDialog<DateTime>(
    context: context,
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        title: const Text('Select Month and Year'),
        content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SizedBox(
              // This SizedBox can be adjusted to change the dialog size if necessary
              width: double.maxFinite, // Makes the dialog take up full width
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  // Month selection GridView
                  GridView.builder(
                    shrinkWrap: true,
                    physics:
                        NeverScrollableScrollPhysics(), // to disable GridView's scrolling
                    itemCount: 12,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount:
                          3, // Reduced from 6 to 3 for larger buttons
                      childAspectRatio: 3 / 1, // Adjusted for wider buttons
                    ),
                    itemBuilder: (BuildContext context, int index) {
                      String monthName =
                          DateFormat.MMM().format(DateTime(0, index + 1));
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedMonth = index + 1;
                          });
                        },
                        child: Container(
                          margin: EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: selectedMonth == index + 1
                                ? Color(
                                    0xFF173235) // Custom color for selected item
                                : Colors.grey[200],
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Center(
                            child: Text(
                              monthName,
                              style: TextStyle(
                                color: selectedMonth == index + 1
                                    ? Colors.white
                                    : Colors.black,
                                fontSize:
                                    16, // Increased font size for readability
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  // Year DropdownButton
                  DropdownButton<int>(
                    isExpanded: true,
                    value: selectedYear,
                    items: yearList.map<DropdownMenuItem<int>>((int value) {
                      return DropdownMenuItem<int>(
                        value: value,
                        child: Text(value.toString()),
                      );
                    }).toList(),
                    onChanged: (newValue) {
                      setState(() {
                        selectedYear = newValue;
                      });
                    },
                  ),
                ],
              ),
            );
          },
        ),
        actions: <Widget>[
          TextButton(
            child: const Text('Cancel'),
            onPressed: () {
              Navigator.of(context).pop(); // Close the dialog
            },
          ),
          TextButton(
            child: const Text('OK'),
            onPressed: () {
              if (selectedYear != null && selectedMonth != null) {
                Navigator.of(context)
                    .pop(DateTime(selectedYear!, selectedMonth!));
              } else {
                throw Exception(
                    "Date not selected or date picker closed without selecting.");
              }
            },
          ),
        ],
      );
    },
  );

  if (pickedDate != null) {
    return pickedDate;
  } else {
    throw Exception(
        "Date not selected or date picker closed without selecting.");
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
