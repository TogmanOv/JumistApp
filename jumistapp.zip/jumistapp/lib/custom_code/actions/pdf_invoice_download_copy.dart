// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../../auth/firebase_auth/auth_util.dart';
import '../../backend/firebase_storage/storage.dart';
import 'package:open_file/open_file.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

// import 'dart:io';
// import 'package:path_provider/path_provider.dart';

Future<String?> pdfInvoiceDownloadCopy(
  BuildContext context,
  String? title,
  String? body,
) async {
  // null safety
  title = title ?? '';
  body = body ?? '';

  final pdf = pw.Document();

  pdf.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      build: (pw.Context context) {
        return [
          pw.Header(
            level: 0,
            child: pw.Center(
              child: pw.Text(
                title!,
                style: pw.TextStyle(
                  fontSize: 18,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          ),
          pw.Paragraph(
            text: body!,
            style: pw.TextStyle(
              fontSize: 10,
            ),
          ),
        ];
      },
    ),
  );

  final pdfSaved = await pdf.save();

  // Get the current date and time
  final now = DateTime.now();

  // Format the date and time as a string
  String formattedDateTime = now.year.toString() +
      '-' +
      now.month.toString().padLeft(2, '0') +
      '-' +
      now.day.toString().padLeft(2, '0') +
      '_' +
      now.hour.toString().padLeft(2, '0') +
      '-' +
      now.minute.toString().padLeft(2, '0') +
      '-' +
      now.second.toString().padLeft(2, '0');

  // Set the file name to the provided formattedDateTime
  final fileName = '$formattedDateTime.pdf';

  // Set the directory where you want to store the file (e.g., a folder named 'pdfs' in your storage)
  String directoryPath = '/users/' + currentUserUid + '/pdfs';

  // Combine the directory path and file name to create the full storage path
  final storagePath = '$directoryPath/$fileName';

  // SAVE IT TO FIREBASE STORE
  final pdfUrl = await uploadData(storagePath, pdfSaved);

  return pdfUrl;
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the button on the right!
