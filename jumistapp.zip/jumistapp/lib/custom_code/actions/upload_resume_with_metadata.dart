// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// ignore: unnecessary_import

import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

Future<void> uploadResumeWithMetadata(String filePath, String userId) async {
  try {
    // Pick a file using File Picker plugin
    final pickedFile =
        await FilePicker.platform.pickFiles(allowMultiple: false);

    if (pickedFile == null) {
      print('No file selected!');
      return;
    }

    final filePath = pickedFile.files.single.path!;

    // Create a storage reference with user ID in the path (adjust as needed)
    final storageRef = FirebaseStorage.instance
        .ref()
        .child('resumes/$userId/${DateTime.now().millisecondsSinceEpoch}');

    // Create metadata with user ID
    final metadata = SettableMetadata(
      contentType: 'application/octet-stream', // Adjust based on file type
      customMetadata: {'user_id': userId},
    );

    // Upload the file with metadata
    final uploadTask = storageRef.putFile(File(filePath));

    // Wait for upload to complete
    final snapshot = await uploadTask.whenComplete(() => null);

    // Get the download URL
    final downloadUrl = await snapshot.ref.getDownloadURL();

    print('Resume uploaded successfully: $downloadUrl');

    // ... Your logic to potentially use the downloadUrl (e.g., store in a variable) ...
  } on FirebaseException catch (e) {
    print('Error uploading resume: $e');
  } catch (e) {
    print('Unexpected error: $e');
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
