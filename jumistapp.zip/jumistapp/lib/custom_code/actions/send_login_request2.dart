// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Custom action code
import 'package:http/http.dart' as http;

Future<String> sendLoginRequest2(
    String apiUrl, String email, String password) async {
  try {
    // Prepare the request URL with query parameters (security risk)
    Uri urlWithQueryParams = Uri.parse(apiUrl);
    Map<String, String> queryParams = {
      'email': email,
      'password': password, // Security risk: sending password in plain text
    };
    urlWithQueryParams =
        urlWithQueryParams.replace(queryParameters: queryParams);

    // Make a POST request to the login API endpoint (not recommended)
    http.Response response = await http.post(
      urlWithQueryParams,
    );

    // Check if the request was successful (status code 200)
    if (response.statusCode == 200) {
      // Login successful, return the response body
      return response.body;
    } else {
      // Login failed, return an error message (optional)
      print('Login failed: ${response.body}');
      return 'Login failed: ${response.statusCode}'; // Example error message
    }
  } catch (error) {
    // Handle any errors that occur during the login request
    print('Error during login: $error');
    return 'An error occurred during login. Please try again later.'; // Example error message
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
