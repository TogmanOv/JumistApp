// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../../auth/firebase_auth/auth_util.dart';
import '../../backend/firebase_storage/storage.dart';
import 'package:open_file/open_file.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

// import 'dart:io';
// import 'package:path_provider/path_provider.dart';

Future<String?> pdfInvoiceDownloadReport(
  BuildContext context,
  String? body,
  String? body2,
  String? body3,
  String? body4,
  String? body5,
  String? body6,
  String? body7,
  String? body8,
  String? body9,
  String? body10,
) async {
  // null safety
  body = body ?? '';
  body2 = body2 ?? '';
  body3 = body3 ?? '';
  body4 = body4 ?? '';
  body5 = body5 ?? '';
  body6 = body6 ?? '';
  body7 = body7 ?? '';
  body8 = body8 ?? '';
  body9 = body9 ?? '';
  body10 = body10 ?? '';

  final pdf = pw.Document();

  pdf.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      build: (pw.Context context) {
        return [
          pw.Header(
            level: 1,
            child: pw.Text('Resume Optimization Tips',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Other Jobs That Match Your Skills',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body2, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Cover Letter',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body3, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Outreach Messages',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body4, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Interview Plan',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body5, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Questions You Can Ask the Company',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body6, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Candidate Assessment',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body7, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Job Summary',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body8, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Compensation Analysis',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body9, style: pw.TextStyle(fontSize: 8)),

          pw.Header(
            level: 1,
            child: pw.Text('Role Expectations',
                style:
                    pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
          ),
          pw.Paragraph(text: body10, style: pw.TextStyle(fontSize: 8)),
          // No need for a PageBreak after the last section
        ];
      },
    ),
  );

  final pdfSaved = await pdf.save();

  // Get the current date and time
  final now = DateTime.now();

  // Format the date and time as a string
  String formattedDateTime = now.year.toString() +
      '-' +
      now.month.toString().padLeft(2, '0') +
      '-' +
      now.day.toString().padLeft(2, '0') +
      '_' +
      now.hour.toString().padLeft(2, '0') +
      '-' +
      now.minute.toString().padLeft(2, '0') +
      '-' +
      now.second.toString().padLeft(2, '0');

  // Set the file name to the provided formattedDateTime
  final fileName = '$formattedDateTime.pdf';

  // Set the directory where you want to store the file (e.g., a folder named 'pdfs' in your storage)
  String directoryPath = '/users/' + currentUserUid + '/pdfs';

  // Combine the directory path and file name to create the full storage path
  final storagePath = '$directoryPath/$fileName';

  // SAVE IT TO FIREBASE STORE
  final pdfUrl = await uploadData(storagePath, pdfSaved);

  return pdfUrl;
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the button on the right!
